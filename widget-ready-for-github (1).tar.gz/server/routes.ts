import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { useCaseRequestSchema, qualificationFormSchema, type UseCaseResponse, type UseCase, type QualificationForm } from "@shared/schema";
import OpenAI from "openai";
import adminRoutes from "./admin-routes";
import zapierRoutes from "./zapier-routes";
import { LeadWorkflowManager } from "./workflows";
import rateLimit from "express-rate-limit";
import slowDown from "express-slow-down";

// Enhanced content moderation function
function moderateContent(content: string): { allowed: boolean; reason?: string } {
  if (!content || content.trim().length === 0) {
    return { allowed: false, reason: "Empty content" };
  }

  const inappropriateTerms = [
    'spam', 'scam', 'fraud', 'hack', 'illegal', 'drugs', 'violence',
    'explicit', 'adult', 'porn', 'gambling', 'casino', 'bet'
  ];
  
  const lowerContent = content.toLowerCase();
  
  // Check for inappropriate terms
  const hasInappropriateContent = inappropriateTerms.some(term => lowerContent.includes(term));
  if (hasInappropriateContent) {
    return { allowed: false, reason: "Inappropriate content detected" };
  }

  // Check for spam patterns - repetitive characters or nonsensical input
  const hasRepeatingChars = /(.)\1{4,}/.test(content); // 5+ same characters in a row
  const hasRandomKeyboard = /qwerty|asdfg|zxcvb|12345|abcdef/i.test(content);
  const isAllSpecialChars = /^[^a-zA-Z0-9\s]+$/.test(content.trim());
  const hasExcessiveSpecialChars = (content.match(/[^a-zA-Z0-9\s]/g) || []).length > content.length * 0.5;
  
  // Check for minimum meaningful content
  const wordCount = content.trim().split(/\s+/).filter(word => word.length > 1).length;
  const hasNumbers = /\d/.test(content);
  const hasLetters = /[a-zA-Z]/.test(content);
  
  if (hasRepeatingChars || hasRandomKeyboard || isAllSpecialChars || hasExcessiveSpecialChars) {
    return { allowed: false, reason: "Spam or nonsensical input detected" };
  }
  
  if (wordCount < 2 && content.length > 10) {
    return { allowed: false, reason: "Insufficient meaningful content" };
  }
  
  if (!hasLetters && !hasNumbers) {
    return { allowed: false, reason: "No meaningful characters detected" };
  }

  return { allowed: true };
}

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

// Rate limiting configurations
const useCaseRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // Maximum 10 requests per IP per 15 minutes
  message: {
    error: "Too many requests from this IP. Please try again in 15 minutes.",
    retryAfter: "15 minutes"
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Skip rate limiting for admin routes or local development
    return req.hostname === 'localhost' || req.hostname === '127.0.0.1';
  }
});

const qualificationRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // Maximum 3 qualification submissions per IP per hour
  message: {
    error: "Too many qualification attempts. Please try again in 1 hour.",
    retryAfter: "1 hour"
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Slow down repeated requests  
const useCaseSlowDown = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 5, // Allow 5 requests per window at full speed
  delayMs: () => 2000, // Add 2 second delay per request after delayAfter
  maxDelayMs: 10000, // Maximum delay of 10 seconds
  validate: { delayMs: false }, // Disable warning
});

// API cost tracking (in-memory for simplicity, could use Redis in production)
const apiUsageTracker = new Map<string, { count: number, resetTime: number, cost: number }>();

function trackAPIUsage(ip: string, estimatedCost: number = 0.01) {
  const key = ip;
  const now = Date.now();
  const hourlyReset = now + (60 * 60 * 1000);
  
  const usage = apiUsageTracker.get(key) || { count: 0, resetTime: hourlyReset, cost: 0 };
  
  // Reset if time window expired
  if (now > usage.resetTime) {
    usage.count = 0;
    usage.cost = 0;
    usage.resetTime = hourlyReset;
  }
  
  usage.count++;
  usage.cost += estimatedCost;
  apiUsageTracker.set(key, usage);
  
  return usage;
}

function isAPIUsageExceeded(ip: string): boolean {
  const usage = apiUsageTracker.get(ip);
  if (!usage) return false;
  
  // Block if more than $5 estimated cost per hour per IP
  const costLimit = 5.00;
  const requestLimit = 50; // Hard limit on requests regardless of cost
  
  return usage.cost > costLimit || usage.count > requestLimit;
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Apply rate limiting to use case endpoint
  app.get("/api/live-use-cases", useCaseRateLimit, useCaseSlowDown, async (req: Request, res) => {
    try {
      const clientIP = req.ip;
      
      // Check API usage limits
      if (isAPIUsageExceeded(clientIP)) {
        return res.status(429).json({
          error: "API usage limit exceeded. Please try again later.",
          retryAfter: "1 hour"
        });
      }
      
      const { sector, challenge, q: keywords } = req.query;
      
      // Validate input
      const validatedInput = useCaseRequestSchema.parse({
        sector: sector as string,
        challenge: challenge as string,
        keywords: keywords as string,
      });

      // Enhanced content moderation - block spam and nonsensical input
      if (validatedInput.keywords) {
        const moderationResult = moderateContent(validatedInput.keywords);
        if (!moderationResult.allowed) {
          console.log(`Content blocked: ${moderationResult.reason} - Input: "${validatedInput.keywords}"`);
          return res.status(400).json({ 
            error: "Invalid input detected",
            message: "Please provide a clear, professional description of your business process or challenge.",
            details: "Your input appears to contain spam or nonsensical content."
          });
        }
      }

      // Save query to database with client info
      const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
      const userAgent = req.get('User-Agent') || 'unknown';
      
      const savedQuery = await storage.saveQuery({
        sector: validatedInput.sector || null,
        challenge: validatedInput.challenge || null,
        keywords: validatedInput.keywords || null,
        ipAddress: clientIp,
        userAgent: userAgent,
      });

      // Check if this involves genuinely mission-critical processes
      const allContent = `${validatedInput.sector || ''} ${validatedInput.challenge || ''} ${validatedInput.keywords || ''}`.toLowerCase();
      
      // Genuinely mission-critical indicators
      const criticalProcesses = [
        'patient care', 'medical device', 'life support', 'emergency response', 'patient safety',
        'medical diagnosis', 'treatment protocol', 'drug administration', 'surgical',
        'production line control', 'quality control system', 'safety shutdown', 'hazardous material',
        'chemical process', 'machinery control', 'equipment monitoring', 'safety interlock',
        'financial transaction', 'payment processing', 'trading system', 'fraud detection',
        'access control', 'authentication system', 'security monitoring', 'compliance audit',
        'power grid', 'energy distribution', 'traffic control', 'emergency system',
        'backup system', 'failover', 'disaster recovery', 'critical infrastructure'
      ];
      
      // Routine business processes that are NOT mission-critical
      const routineProcesses = [
        'document classification', 'document routing', 'data entry', 'email sorting',
        'invoice processing', 'customer service', 'marketing automation', 'lead generation',
        'scheduling', 'inventory tracking', 'report generation', 'workflow automation',
        'content management', 'social media', 'employee onboarding', 'training materials',
        'meeting notes', 'project management', 'time tracking', 'expense reporting'
      ];
      
      const hasCriticalProcesses = criticalProcesses.some(process => allContent.includes(process));
      const hasRoutineProcesses = routineProcesses.some(process => allContent.includes(process));
      
      // Only flag as mission-critical if specific critical processes are mentioned AND it's not just routine work
      const isMissionCritical = hasCriticalProcesses && !hasRoutineProcesses;

      // Build OpenAI prompt
      const prompt = `
You are an AI consultant for small and medium businesses. Generate 3-5 specific, actionable AI solutions based on the following criteria:

${validatedInput.sector ? `Sector: ${validatedInput.sector}` : ''}
${validatedInput.challenge ? `Business Challenge: ${validatedInput.challenge}` : ''}
${validatedInput.keywords ? `Current Setup and Goals: ${validatedInput.keywords}` : ''}

${isMissionCritical ? `
IMPORTANT SAFETY GUIDELINES - This involves mission-critical processes that affect safety, security, or compliance:
- Multiply all short timelines by 1.5× (e.g., "2-4 weeks" becomes "3-6 weeks") 
- Increase complexity one level ("Low"→"Medium", "Medium"→"High") when safety validations are needed
- Increase investment one level when additional safety measures are required
- Include this caution in "whyThisFitsYou": "Caution: This use case impacts mission-critical systems—plan extra time for safety validations, rigorous testing, and integration."
` : ''}

For each use case, provide:
- A clear, specific title
- A compelling value proposition with measurable benefits
- Complexity level (Low, Medium, or High)${isMissionCritical ? ' - adjusted for mission-critical requirements' : ''}
- Time to value (estimate realistic timeframe${isMissionCritical ? ' with safety buffers' : ': 1-2 weeks, 3-4 weeks, 1-2 months, or 3+ months'})
- Potential investment level (Low, Medium, or High)${isMissionCritical ? ' - accounting for additional safety measures' : ''}
- Implementation type: "Off-the-shelf" (using existing tools like Zapier, Microsoft Power Automate, or built-in features) or "Custom Build" (requires tailored development or custom integrations)
- Why this fits you: One line explaining how this connects to their specific sector, challenge, or setup details${isMissionCritical ? ' (include safety caution if applicable)' : ''}
- Call-to-action: Use "Launch a Quick Pilot" for off-the-shelf solutions, "Book Strategy Session" for custom builds

${validatedInput.sortBy === 'quickest' ? 'Prioritize off-the-shelf, low-complexity solutions that can be implemented quickly.' : validatedInput.sortBy === 'impact' ? 'Prioritize solutions with the highest ROI and business impact, even if they require more time or investment.' : 'Balance quick wins with impactful solutions, starting with off-the-shelf options.'}

Focus on practical, implementable solutions using existing tools and platforms. Include AI-powered solutions alongside traditional process improvements. Avoid overly technical jargon.${isMissionCritical ? ' Prioritize safety and thorough testing in mission-critical environments.' : ''}

Respond in JSON format with this structure:
{
  "useCases": [
    {
      "title": "string",
      "valueProposition": "string", 
      "complexity": "Low|Medium|High",
      "timeToValue": "string",
      "potentialInvestment": "Low|Medium|High",
      "implementationType": "Off-the-shelf|Custom Build",
      "whyThisFitsYou": "string",
      "cta": "Launch a Quick Pilot|Book Strategy Session"
    }
  ]
}
`;

      // Track API usage before making the call
      const estimatedCost = 0.015; // Estimated cost for gpt-4o with 2000 max tokens
      trackAPIUsage(clientIP, estimatedCost);
      
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert AI consultant specializing in practical SMB solutions. Always respond with valid JSON in the exact format requested."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 2000,
      });

      const result = JSON.parse(response.choices[0].message.content || '{"useCases":[]}');
      
      // Validate the response structure
      if (!result.useCases || !Array.isArray(result.useCases)) {
        throw new Error("Invalid response format from OpenAI");
      }

      const limitedUseCases = result.useCases.slice(0, 5); // Limit to 5 use cases
      
      // Sort use cases to prioritize off-the-shelf and low complexity
      const sortedUseCases = limitedUseCases.sort((a: UseCase, b: UseCase) => {
        // First, prioritize off-the-shelf
        if (a.implementationType === 'Off-the-shelf' && b.implementationType === 'Custom Build') return -1;
        if (a.implementationType === 'Custom Build' && b.implementationType === 'Off-the-shelf') return 1;
        
        // Then by complexity
        const complexityOrder = { 'Low': 0, 'Medium': 1, 'High': 2 };
        return complexityOrder[a.complexity] - complexityOrder[b.complexity];
      });

      // Function to calculate realistic ROI metrics based on use case content
      function calculateROIMetric(useCase: any): string {
        const title = useCase.title.toLowerCase();
        const value = useCase.valueProposition.toLowerCase();
        const keywords = `${validatedInput.keywords || ''}`.toLowerCase();
        
        // Base calculations on actual content analysis
        if (title.includes('customer service') || title.includes('support') || value.includes('customer')) {
          // Estimate based on typical customer service volume
          if (keywords.includes('hour') || keywords.includes('daily')) {
            const hourMatch = keywords.match(/(\d+)\s*hour/);
            if (hourMatch) {
              const hours = parseInt(hourMatch[1]);
              const savedHours = Math.round(hours * 0.6); // Realistic efficiency improvement
              return `Save ${savedHours}+ hours/week on customer inquiries`;
            }
          }
          return "Improve response consistency and speed";
        }
        
        if (title.includes('document') || title.includes('processing') || value.includes('document')) {
          // Calculate based on document volume mentioned
          if (keywords.includes('invoice') || keywords.includes('pdf')) {
            const numberMatch = keywords.match(/(\d+)/);
            if (numberMatch) {
              const volume = parseInt(numberMatch[1]);
              if (volume > 100) return "Handle 3-5x more volume with same resources";
              if (volume > 50) return "Reduce processing time by 60-75%";
              return "Process documents 3x faster";
            }
          }
          return "Streamline document workflows significantly";
        }
        
        if (title.includes('email') || title.includes('communication') || value.includes('email')) {
          if (keywords.includes('daily') || keywords.includes('hour')) {
            return "Reduce email workload by 50-70%";
          }
          return "Organize and prioritize communications better";
        }
        
        if (title.includes('data entry') || title.includes('input') || value.includes('data entry')) {
          return "Minimize manual data entry by 80%+";
        }
        
        if (title.includes('inventory') || title.includes('stock') || value.includes('inventory')) {
          return "Prevent 70%+ of stock-out situations";
        }
        
        if (title.includes('scheduling') || title.includes('appointment') || value.includes('scheduling')) {
          return "Save 6-10 hours/week on scheduling coordination";
        }
        
        if (title.includes('lead') || title.includes('sales') || value.includes('lead')) {
          return "Improve lead quality and conversion rates";
        }
        
        if (title.includes('report') || title.includes('analytics') || value.includes('report')) {
          return "Generate reports in minutes instead of hours";
        }
        
        // Default calculation based on complexity and time to value
        if (useCase.complexity === 'Low' && useCase.timeToValue.includes('1-2 weeks')) {
          return "Save 4-6 hours/week on routine processes";
        } else if (useCase.complexity === 'Medium') {
          return "Improve operational efficiency by 50-70%";
        } else {
          return "Transform key business processes";
        }
      }

      // Add ROI metrics to each use case
      const useCasesWithROI = sortedUseCases.map((useCase: UseCase) => ({
        ...useCase,
        roiMetric: calculateROIMetric(useCase)
      }));

      // Save results to database
      await storage.saveResults(savedQuery.id, useCasesWithROI.map((useCase: any) => ({
        title: useCase.title,
        valueProposition: useCase.valueProposition,
        complexity: useCase.complexity,
        timeToValue: useCase.timeToValue,
        potentialInvestment: useCase.potentialInvestment,
        implementationType: useCase.implementationType,
        whyThisFitsYou: useCase.whyThisFitsYou,
        cta: useCase.cta,
        roiMetric: useCase.roiMetric,
      })));

      const useCaseResponse = {
        useCases: useCasesWithROI,
        queryId: savedQuery.id
      };

      res.json(useCaseResponse);

    } catch (error) {
      console.error('Error generating use cases:', error);
      res.status(500).json({ 
        error: "Failed to generate use cases",
        message: "Please try again with different parameters." 
      });
    }
  });

  // Lead qualification endpoint with rate limiting
  app.post("/api/qualify-lead", qualificationRateLimit, async (req: Request, res) => {
    try {
      const validatedInput = qualificationFormSchema.parse(req.body);
      
      // Check if this lead came from spam/low-quality content
      const selectedUseCaseTitle = req.body.selectedUseCaseTitle || null;
      const queryId = req.body.queryId || null;
      
      // Calculate lead score (start lower for potential spam)
      let leadScore = 0;
      let leadTier = "Low-Intent";
      let isLowQuality = false;
      
      // Check if the use case selection seems suspicious
      if (selectedUseCaseTitle && selectedUseCaseTitle.length < 10) {
        isLowQuality = true;
      }
      
      // Budget scoring
      switch(validatedInput.budgetRange) {
        case "£10K+": leadScore += 40; break;
        case "£5-10K": leadScore += 30; break;
        case "£1-5K": leadScore += 20; break;
        case "<£1K": leadScore += 5; break;
      }
      
      // Timeline scoring
      switch(validatedInput.desiredStart) {
        case "Immediately": leadScore += 30; break;
        case "1-3 months": leadScore += 20; break;
        case "Undecided": leadScore += 5; break;
      }
      
      // Company size scoring (larger companies often have bigger budgets)
      switch(validatedInput.companySize) {
        case "200+": leadScore += 20; break;
        case "51-200": leadScore += 15; break;
        case "11-50": leadScore += 10; break;
        case "1-10": leadScore += 5; break;
      }
      
      // Determine lead tier (cap low-quality leads at Medium-Intent)
      if (isLowQuality) {
        leadTier = "Low-Intent";
        leadScore = Math.min(leadScore, 30); // Cap spam leads at low score
      } else if (leadScore >= 70) {
        leadTier = "High-Intent";
      } else if (leadScore >= 40) {
        leadTier = "Medium-Intent";
      }
      

      
      // Save to database with full context
      const savedLead = await storage.saveQualificationLead({
        queryId,
        selectedUseCaseTitle,
        email: validatedInput.email,
        companySize: validatedInput.companySize,
        budgetRange: validatedInput.budgetRange,
        desiredStart: validatedInput.desiredStart,
        leadScore,
        leadTier,
      });

      // Trigger appropriate workflow based on lead tier
      await LeadWorkflowManager.triggerWorkflow(savedLead, {
        budgetRange: validatedInput.budgetRange,
        companySize: validatedInput.companySize,
        desiredStart: validatedInput.desiredStart,
      });
      
      // Return different responses based on lead tier
      let nextSteps = "";
      switch(leadTier) {
        case "High-Intent":
          nextSteps = "https://calendly.com/gerperdisatt/acuity-ai-strategy-session";
          break;
        case "Medium-Intent":
          nextSteps = "We'll email you a tailored implementation outline and connect you with our team.";
          break;
        default:
          nextSteps = "We'll send you helpful resources and best practices via email.";
      }
      
      res.json({
        leadTier,
        leadScore,
        nextSteps,
        message: leadTier === "High-Intent" ? 
          "Perfect! You're ready to move forward with implementation." :
          leadTier === "Medium-Intent" ?
          "We'll create a custom implementation roadmap for your specific needs." :
          "We'll share relevant resources and best practices to help you explore further."
      });
      
    } catch (error) {
      console.error("Error qualifying lead:", error);
      res.status(500).json({ 
        error: "Internal server error",
        message: "Failed to process qualification. Please try again." 
      });
    }
  });

  // Mount admin routes
  app.use('/api/admin', adminRoutes);
  
  // Mount Zapier integration routes
  app.use('/api/zapier', zapierRoutes);

  const httpServer = createServer(app);
  return httpServer;
}
