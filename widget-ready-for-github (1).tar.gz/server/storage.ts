import { useCaseQueries, useCaseResults, qualificationLeads, type InsertUseCaseQuery, type InsertUseCaseResult, type InsertQualificationLead, type UseCaseQuery, type UseCaseResult, type QualificationLead } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  saveQuery(query: InsertUseCaseQuery): Promise<UseCaseQuery>;
  saveResults(queryId: number, results: Omit<InsertUseCaseResult, 'queryId'>[]): Promise<UseCaseResult[]>;
  getQueryWithResults(queryId: number): Promise<{ query: UseCaseQuery; results: UseCaseResult[] } | undefined>;
  saveQualificationLead(lead: InsertQualificationLead): Promise<QualificationLead>;
}

export class DatabaseStorage implements IStorage {
  async saveQuery(query: InsertUseCaseQuery): Promise<UseCaseQuery> {
    const [savedQuery] = await db
      .insert(useCaseQueries)
      .values(query)
      .returning();
    return savedQuery;
  }

  async saveResults(queryId: number, results: Omit<InsertUseCaseResult, 'queryId'>[]): Promise<UseCaseResult[]> {
    const resultsWithQueryId = results.map(result => ({
      ...result,
      queryId,
    }));
    
    const savedResults = await db
      .insert(useCaseResults)
      .values(resultsWithQueryId)
      .returning();
    
    return savedResults;
  }

  async getQueryWithResults(queryId: number): Promise<{ query: UseCaseQuery; results: UseCaseResult[] } | undefined> {
    const [query] = await db
      .select()
      .from(useCaseQueries)
      .where(eq(useCaseQueries.id, queryId));

    if (!query) return undefined;

    const results = await db
      .select()
      .from(useCaseResults)
      .where(eq(useCaseResults.queryId, queryId));

    return { query, results };
  }

  async saveQualificationLead(lead: InsertQualificationLead): Promise<QualificationLead> {
    const [savedLead] = await db
      .insert(qualificationLeads)
      .values(lead)
      .returning();
    return savedLead;
  }
}

export const storage = new DatabaseStorage();
