import { Router } from 'express';
import { db } from './db';
import { qualificationLeads, useCaseQueries, useCaseResults } from '@shared/schema';
import { desc, sql, count, eq } from 'drizzle-orm';
import { requireAdminAuth, requireAdminLogin } from './admin-auth';

const router = Router();

// API Access for embedded widget lead data
router.get('/api/leads', requireAdminAuth, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 50,
      tier,
      dateFrom,
      dateTo,
      format = 'json'
    } = req.query;

    const offset = (parseInt(page as string) - 1) * parseInt(limit as string);
    
    // Build dynamic WHERE clause
    let whereClause = '';
    const params: any[] = [parseInt(limit as string), offset];
    let paramIndex = 3;

    if (tier) {
      whereClause += ` WHERE ql.lead_tier = $${paramIndex}`;
      params.push(tier);
      paramIndex++;
    }

    if (dateFrom) {
      whereClause += whereClause ? ' AND' : ' WHERE';
      whereClause += ` ql.created_at >= $${paramIndex}`;
      params.push(new Date(dateFrom as string));
      paramIndex++;
    }

    if (dateTo) {
      whereClause += whereClause ? ' AND' : ' WHERE';
      whereClause += ` ql.created_at <= $${paramIndex}`;
      params.push(new Date(dateTo as string));
      paramIndex++;
    }

    const leadsResult = await db.execute(sql.raw(`
      SELECT 
        ql.id,
        ql.email,
        ql.company_size as "companySize",
        ql.budget_range as "budgetRange", 
        ql.desired_start as "desiredStart",
        ql.lead_score as "leadScore",
        ql.lead_tier as "leadTier",
        ql.selected_use_case_title as "selectedUseCaseTitle",
        ql.created_at as "createdAt",
        uq.sector,
        uq.challenge,
        uq.keywords,
        uq.ip_address as "ipAddress"
      FROM qualification_leads ql
      LEFT JOIN use_case_queries uq ON ql.query_id = uq.id
      ${whereClause}
      ORDER BY ql.created_at DESC
      LIMIT $1 OFFSET $2
    `, params));

    const leads = leadsResult.rows;

    // CSV format support for easy import
    if (format === 'csv') {
      const csvHeader = 'Email,Company Size,Budget Range,Timeline,Lead Score,Lead Tier,Selected Use Case,Created At,Sector,Challenge,Keywords\n';
      const csvRows = leads.map(lead => 
        `"${lead.email}","${lead.companySize}","${lead.budgetRange}","${lead.desiredStart}","${lead.leadScore}","${lead.leadTier}","${lead.selectedUseCaseTitle}","${lead.createdAt}","${lead.sector || ''}","${lead.challenge || ''}","${lead.keywords || ''}"`
      ).join('\n');
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="leads-${new Date().toISOString().split('T')[0]}.csv"`);
      return res.send(csvHeader + csvRows);
    }

    res.json({
      leads,
      meta: {
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        total: leads.length,
        filters: { tier, dateFrom, dateTo }
      }
    });
  } catch (error) {
    console.error('API Error fetching leads:', error);
    res.status(500).json({ error: 'Failed to fetch leads' });
  }
});

// Get all qualification leads with pagination and context (Dashboard)
router.get('/leads', requireAdminLogin, async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = (page - 1) * limit;

    // Get leads with context using raw SQL to avoid join issues
    const leadsResult = await db.execute(sql`
      SELECT 
        ql.id,
        ql.email,
        ql.company_size as "companySize",
        ql.budget_range as "budgetRange",
        ql.desired_start as "desiredStart",
        ql.lead_score as "leadScore",
        ql.lead_tier as "leadTier",
        ql.selected_use_case_title as "selectedUseCaseTitle",
        ql.created_at as "createdAt",
        uq.sector,
        uq.challenge,
        uq.keywords,
        uq.ip_address as "ipAddress",
        uq.user_agent as "userAgent"
      FROM qualification_leads ql
      LEFT JOIN use_case_queries uq ON ql.query_id = uq.id
      ORDER BY ql.created_at DESC
      LIMIT ${limit} OFFSET ${offset}
    `);
    
    const leads = leadsResult.rows;

    const totalCount = await db
      .select({ count: count() })
      .from(qualificationLeads);

    res.json({
      leads,
      pagination: {
        page,
        limit,
        total: totalCount[0].count,
        totalPages: Math.ceil(totalCount[0].count / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching leads:', error);
    res.status(500).json({ error: 'Failed to fetch leads' });
  }
});

// Webhook endpoint for real-time lead notifications
router.post('/api/webhook/lead-created', requireAdminAuth, async (req, res) => {
  try {
    const { leadId } = req.body;
    
    if (!leadId) {
      return res.status(400).json({ error: 'Lead ID required' });
    }

    // Get lead details
    const leadResult = await db.execute(sql`
      SELECT 
        ql.*,
        uq.sector,
        uq.challenge,
        uq.keywords
      FROM qualification_leads ql
      LEFT JOIN use_case_queries uq ON ql.query_id = uq.id
      WHERE ql.id = ${leadId}
    `);

    if (leadResult.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    const lead = leadResult.rows[0];
    
    // Here you could integrate with your CRM, email system, etc.
    console.log('Webhook: New lead created:', {
      email: lead.email,
      tier: lead.lead_tier,
      score: lead.lead_score
    });

    res.json({ success: true, message: 'Webhook processed' });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// API Analytics endpoint
router.get('/api/analytics', requireAdminAuth, async (req, res) => {
  try {
    const { period = '7d' } = req.query;
    
    let dateFilter = '';
    if (period === '24h') {
      dateFilter = "WHERE created_at >= NOW() - INTERVAL '24 hours'";
    } else if (period === '7d') {
      dateFilter = "WHERE created_at >= NOW() - INTERVAL '7 days'";
    } else if (period === '30d') {
      dateFilter = "WHERE created_at >= NOW() - INTERVAL '30 days'";
    }

    // Lead tier distribution
    const tierStats = await db.execute(sql.raw(`
      SELECT 
        lead_tier,
        COUNT(*) as count,
        AVG(lead_score) as avg_score
      FROM qualification_leads 
      ${dateFilter}
      GROUP BY lead_tier
    `));

    // Top sectors
    const sectorStats = await db.execute(sql.raw(`
      SELECT 
        uq.sector,
        COUNT(*) as lead_count,
        AVG(ql.lead_score) as avg_score
      FROM qualification_leads ql
      LEFT JOIN use_case_queries uq ON ql.query_id = uq.id
      ${dateFilter.replace('created_at', 'ql.created_at')}
      GROUP BY uq.sector
      ORDER BY lead_count DESC
      LIMIT 10
    `));

    // Conversion metrics
    const conversionStats = await db.execute(sql.raw(`
      SELECT 
        COUNT(*) as total_queries,
        COUNT(ql.id) as qualified_leads,
        ROUND(COUNT(ql.id)::numeric / COUNT(*)::numeric * 100, 2) as conversion_rate
      FROM use_case_queries uq
      LEFT JOIN qualification_leads ql ON uq.id = ql.query_id
      ${dateFilter.replace('created_at', 'uq.created_at')}
    `));

    res.json({
      period,
      tiers: tierStats.rows,
      sectors: sectorStats.rows,
      conversion: conversionStats.rows[0]
    });
  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

// Get leads by tier (Dashboard)
router.get('/leads/by-tier', requireAdminLogin, async (req, res) => {
  try {
    const leadsByTier = await db
      .select({
        leadTier: qualificationLeads.leadTier,
        count: count()
      })
      .from(qualificationLeads)
      .groupBy(qualificationLeads.leadTier);

    res.json(leadsByTier);
  } catch (error) {
    console.error('Error fetching leads by tier:', error);
    res.status(500).json({ error: 'Failed to fetch leads by tier' });
  }
});

// Get recent activity summary
router.get('/dashboard', async (req, res) => {
  try {
    const [totalLeads, recentLeads, highIntentLeads, queriesCount] = await Promise.all([
      db.select({ count: count() }).from(qualificationLeads),
      db.select({ count: count() }).from(qualificationLeads).where(
        sql`${qualificationLeads.createdAt} >= NOW() - INTERVAL '7 days'`
      ),
      db.select({ count: count() }).from(qualificationLeads).where(
        sql`${qualificationLeads.leadTier} = 'High-Intent'`
      ),
      db.select({ count: count() }).from(useCaseQueries)
    ]);

    const recentActivity = await db
      .select({
        id: qualificationLeads.id,
        email: qualificationLeads.email,
        companySize: qualificationLeads.companySize,
        budgetRange: qualificationLeads.budgetRange,
        leadTier: qualificationLeads.leadTier,
        leadScore: qualificationLeads.leadScore,
        createdAt: qualificationLeads.createdAt
      })
      .from(qualificationLeads)
      .orderBy(desc(qualificationLeads.createdAt))
      .limit(5);

    res.json({
      stats: {
        totalLeads: totalLeads[0].count,
        recentLeads: recentLeads[0].count,
        highIntentLeads: highIntentLeads[0].count,
        totalQueries: queriesCount[0].count
      },
      recentActivity
    });
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
  }
});

export default router;