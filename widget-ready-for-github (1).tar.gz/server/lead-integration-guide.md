# Lead Data Access for Embedded Widget

## Overview
When the Acuity AI Use Case Explorer is embedded on your website, all lead data flows into a secure backend database. Here are the methods to access and integrate this data with your existing systems.

## 1. REST API Access

### Authentication
All API endpoints require authentication via Bearer token:
```bash
Authorization: Bearer YOUR_ADMIN_TOKEN
```
Set `ADMIN_API_TOKEN` environment variable for your token.

### Get Leads Endpoint
```bash
GET /admin/api/leads
```

#### Parameters:
- `page` (optional): Page number (default: 1)
- `limit` (optional): Results per page (default: 50, max: 100)
- `tier` (optional): Filter by lead tier (`High-Intent`, `Medium-Intent`, `Low-Intent`)
- `dateFrom` (optional): Start date filter (ISO format)
- `dateTo` (optional): End date filter (ISO format)
- `format` (optional): Response format (`json` or `csv`)

#### Example Requests:
```bash
# Get all high-intent leads from last 7 days
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://your-widget.repl.co/admin/api/leads?tier=High-Intent&dateFrom=2025-01-22"

# Export leads as CSV
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://your-widget.repl.co/admin/api/leads?format=csv" \
  > leads.csv
```

#### Response Format:
```json
{
  "leads": [
    {
      "id": 123,
      "email": "john@company.com",
      "companySize": "11-50",
      "budgetRange": "£5-10K",
      "desiredStart": "1-3 months",
      "leadScore": 65,
      "leadTier": "Medium-Intent",
      "selectedUseCaseTitle": "AI-Powered Email Automation",
      "createdAt": "2025-01-29T21:08:51.672Z",
      "sector": "Finance",
      "challenge": "Manual Data Entry",
      "keywords": "process invoices daily",
      "ipAddress": "192.168.1.1"
    }
  ],
  "meta": {
    "page": 1,
    "limit": 50,
    "total": 25,
    "filters": {
      "tier": "High-Intent",
      "dateFrom": "2025-01-22"
    }
  }
}
```

### Analytics Endpoint
```bash
GET /admin/api/analytics
```

#### Parameters:
- `period` (optional): Time period (`24h`, `7d`, `30d`)

#### Response:
```json
{
  "period": "7d",
  "tiers": [
    { "lead_tier": "High-Intent", "count": 12, "avg_score": 78.5 },
    { "lead_tier": "Medium-Intent", "count": 24, "avg_score": 55.2 },
    { "lead_tier": "Low-Intent", "count": 8, "avg_score": 28.1 }
  ],
  "sectors": [
    { "sector": "Finance", "lead_count": 15, "avg_score": 62.3 },
    { "sector": "Healthcare", "lead_count": 12, "avg_score": 58.7 }
  ],
  "conversion": {
    "total_queries": 145,
    "qualified_leads": 44,
    "conversion_rate": "30.34"
  }
}
```

## 2. Webhook Integration

### Real-time Lead Notifications
Configure webhooks to receive instant notifications when new leads are captured:

```bash
POST /admin/api/webhook/lead-created
Content-Type: application/json
Authorization: Bearer YOUR_TOKEN

{
  "leadId": 123
}
```

This endpoint can trigger actions in your CRM, email marketing platform, or notification system.

## 3. Web Dashboard Access

### Admin Login
Access the web dashboard at: `https://your-widget.repl.co/admin/login`

Default credentials can be set via environment variables:
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`

### Dashboard Features:
- **Lead Management**: View, filter, and export leads
- **Analytics**: Conversion rates, lead scoring, sector analysis
- **Workflow Management**: Monitor automated nurture campaigns
- **Integration Status**: Check Zapier/webhook health

## 4. CRM Integration Examples

### Salesforce Integration
```javascript
// Example webhook handler for Salesforce
async function handleNewLead(leadData) {
  const sfLead = {
    FirstName: leadData.email.split('@')[0],
    LastName: 'Unknown',
    Email: leadData.email,
    Company: `${leadData.companySize} employee company`,
    LeadSource: 'Acuity AI Widget',
    Budget__c: leadData.budgetRange,
    Timeline__c: leadData.desiredStart,
    Lead_Score__c: leadData.leadScore,
    Use_Case__c: leadData.selectedUseCaseTitle
  };
  
  await salesforce.createLead(sfLead);
}
```

### HubSpot Integration
```javascript
// Example HubSpot contact creation
async function createHubSpotContact(leadData) {
  const properties = {
    email: leadData.email,
    company_size: leadData.companySize,
    budget_range: leadData.budgetRange,
    desired_timeline: leadData.desiredStart,
    lead_score: leadData.leadScore,
    lead_source: 'Acuity AI Widget'
  };
  
  await hubspot.contacts.create({ properties });
}
```

## 5. Automated Workflows

### Zapier Integration
The widget includes built-in Zapier webhooks for:
- **High-Intent Leads**: Direct to Calendly booking
- **Medium-Intent Leads**: Email nurture sequence (4-day follow-up)
- **Low-Intent Leads**: Educational content delivery (14-day sequence)

### Email Marketing
Leads are automatically tagged by tier and use case for targeted campaigns:
```javascript
// Example Mailchimp integration
const listId = 'your-mailchimp-list';
const tags = [
  leadData.leadTier.toLowerCase().replace('-', '_'),
  leadData.sector?.toLowerCase(),
  'acuity_widget'
];

await mailchimp.lists.addListMember(listId, {
  email_address: leadData.email,
  tags: tags,
  merge_fields: {
    COMPANY_SIZE: leadData.companySize,
    BUDGET: leadData.budgetRange,
    USE_CASE: leadData.selectedUseCaseTitle
  }
});
```

## 6. Data Export Options

### CSV Export
Regular CSV exports for analysis or import into other systems:
```bash
# Daily export script
curl -H "Authorization: Bearer $TOKEN" \
  "https://your-widget.repl.co/admin/api/leads?format=csv&dateFrom=$(date -d '1 day ago' +%Y-%m-%d)" \
  > "leads-$(date +%Y-%m-%d).csv"
```

### Database Access
For advanced integrations, direct database access is available through the PostgreSQL connection string in `DATABASE_URL`.

**Tables:**
- `qualification_leads`: Lead qualification data
- `use_case_queries`: Original widget queries
- `use_case_results`: Generated AI recommendations

## 7. Security Considerations

- All API endpoints use secure authentication
- Rate limiting prevents abuse (3 qualification attempts per hour per IP)
- Lead data includes IP addresses for fraud detection
- GDPR compliance: Include data deletion endpoints as needed

## 8. Monitoring & Alerts

### API Usage Monitoring
Track API calls and set up alerts for unusual activity:
```bash
# Check API health
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://your-widget.repl.co/admin/api/analytics?period=24h"
```

### Lead Quality Monitoring
Monitor conversion rates and lead scores to optimize widget performance:
- High conversion rates (>30%) indicate good traffic quality
- Low average lead scores may indicate spam or poor traffic sources
- Sector analysis helps identify best-performing industries

This comprehensive system ensures you have full visibility and control over all leads generated by your embedded widget while maintaining security and scalability.