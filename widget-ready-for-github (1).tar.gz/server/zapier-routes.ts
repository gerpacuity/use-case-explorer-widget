import { Router } from 'express';
import { db } from './db';
import { qualificationLeads, useCaseQueries } from '@shared/schema';
import { desc, sql, eq } from 'drizzle-orm';

const router = Router();

// Get all workflow-ready leads for Zapier integration
router.get('/leads', async (req, res) => {
  try {
    const { tier, limit = 50 } = req.query;
    
    let query = db
      .select({
        id: qualificationLeads.id,
        email: qualificationLeads.email,
        leadTier: qualificationLeads.leadTier,
        leadScore: qualificationLeads.leadScore,
        selectedUseCaseTitle: qualificationLeads.selectedUseCaseTitle,
        companySize: qualificationLeads.companySize,
        budgetRange: qualificationLeads.budgetRange,
        desiredStart: qualificationLeads.desiredStart,
        createdAt: qualificationLeads.createdAt,
        // Context from original query
        sector: useCaseQueries.sector,
        challenge: useCaseQueries.challenge,
        keywords: useCaseQueries.keywords,
      })
      .from(qualificationLeads)
      .leftJoin(useCaseQueries, eq(qualificationLeads.queryId, useCaseQueries.id))
      .orderBy(desc(qualificationLeads.createdAt))
      .limit(parseInt(limit as string));

    // Filter by tier if specified
    if (tier && (tier === 'Medium-Intent' || tier === 'Low-Intent')) {
      query = query.where(eq(qualificationLeads.leadTier, tier as string));
    }

    const leads = await query;

    // Transform for Zapier-friendly format
    const zapierLeads = leads.map(lead => ({
      lead_id: lead.id,
      lead_email: lead.email,
      lead_tier: lead.leadTier,
      lead_score: lead.leadScore,
      selected_use_case: lead.selectedUseCaseTitle || 'Not specified',
      company_size: lead.companySize,
      budget_range: lead.budgetRange,
      desired_start: lead.desiredStart,
      sector: lead.sector || 'Not specified',
      challenge: lead.challenge || 'Not specified',
      keywords: lead.keywords || 'Not specified',
      created_at: lead.createdAt,
      workflow_type: lead.leadTier === 'Medium-Intent' ? 'medium_intent_nurture' : 'low_intent_nurture',
      email_template: lead.leadTier === 'Medium-Intent' ? 'implementation_outline' : 'educational_resources',
      follow_up_days: lead.leadTier === 'Medium-Intent' ? 4 : 14,
    }));

    res.json({
      leads: zapierLeads,
      count: zapierLeads.length,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error fetching Zapier leads:', error);
    res.status(500).json({ error: 'Failed to fetch leads' });
  }
});

// Get templates for Zapier (Dripify, Email, etc.)
router.get('/templates', async (req, res) => {
  try {
    const templates = {
      // Dripify LinkedIn Templates
      dripify_medium_intent_connection: {
        platform: "linkedin",
        message_type: "connection_request",
        content: "Hi {{first_name}}, I saw you explored {{selected_use_case}} solutions on our platform. Based on your {{company_size}} team size, I think we could create something really valuable together. Would love to connect and share some relevant insights.",
        variables: ["first_name", "selected_use_case", "company_size"]
      },
      dripify_medium_intent_roadmap: {
        platform: "linkedin", 
        message_type: "follow_up_message",
        delay_days: 2,
        content: "Thanks for connecting! I noticed you're interested in {{selected_use_case}} with a {{budget_range}} budget range.\n\nI've actually helped several companies your size ({{company_size}}) implement similar solutions. The typical approach involves:\n\n• Phase 1: Process mapping & requirements (2 weeks)\n• Phase 2: Pilot implementation (4-6 weeks)\n• Phase 3: Full rollout & optimization (6-8 weeks)\n\nGiven your \"{{desired_start}}\" timeline preference, we could adjust this schedule. Would a quick 15-minute call this week be helpful to discuss your specific challenges?",
        variables: ["selected_use_case", "budget_range", "company_size", "desired_start"]
      },
      dripify_low_intent_connection: {
        platform: "linkedin",
        message_type: "connection_request", 
        content: "Hi {{first_name}}, noticed you explored AI automation options recently. I share practical implementation tips and case studies that might be valuable for your business. Would love to connect!",
        variables: ["first_name"]
      },
      dripify_low_intent_value_first: {
        platform: "linkedin",
        message_type: "follow_up_message",
        delay_days: 3,
        content: "Thanks for connecting! I've put together a quick AI Automation Readiness Checklist specifically for {{company_size}} companies that helps identify the best opportunities to start with.\n\nNo sales pitch - just practical insights from helping 100+ businesses implement smart automation. Would you like me to send it over?",
        variables: ["company_size"]
      },
      
      // Email Templates (backup/alternative)
      medium_intent_implementation_outline: {
        platform: "email",
        subject: "Your {{selected_use_case}} Implementation Roadmap - Next Steps",
        preview: "Custom implementation timeline based on your {{budget_range}} budget and {{desired_start}} timeline",
        content_type: "html",
        variables: [
          "lead_email",
          "selected_use_case", 
          "company_size",
          "budget_range",
          "desired_start",
          "sector",
          "challenge"
        ]
      },
      low_intent_educational_resources: {
        platform: "email",
        subject: "AI Automation Best Practices Guide + Weekly Insights",
        preview: "Your complete resource pack for smart automation decisions",
        content_type: "html",
        variables: [
          "lead_email",
          "selected_use_case",
          "sector"
        ]
      }
    };

    res.json({
      templates,
      usage: "Use these templates in your Zapier email automation workflows",
      webhook_url: `${req.protocol}://${req.get('host')}/api/zapier/webhook`,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error fetching templates:', error);
    res.status(500).json({ error: 'Failed to fetch templates' });
  }
});

// Webhook endpoint for Zapier to confirm email delivery
router.post('/webhook/email-sent', async (req, res) => {
  try {
    const { lead_email, template_type, sent_at, zapier_task_id } = req.body;
    
    console.log(`
========== EMAIL DELIVERY CONFIRMED ==========
Lead: ${lead_email}
Template: ${template_type}
Sent At: ${sent_at}
Zapier Task ID: ${zapier_task_id}
============================================
    `);

    // Here you could update your database to track email delivery
    // await db.insert(emailDeliveries).values({...})

    res.json({ 
      status: 'confirmed',
      message: 'Email delivery logged successfully',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error processing email confirmation:', error);
    res.status(500).json({ error: 'Failed to process confirmation' });
  }
});

export default router;