// Email template system for lead nurturing workflows
export class EmailTemplates {
  
  // Medium-intent implementation outline email
  static mediumIntentImplementationOutline(lead: any, selectedUseCase: string) {
    return {
      subject: `Your ${selectedUseCase} Implementation Roadmap - Next Steps`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #7c3aed;">Your Custom Implementation Roadmap</h2>
          
          <p>Hi there,</p>
          
          <p>Thank you for your interest in <strong>${selectedUseCase}</strong>. Based on your company profile, I've created a tailored implementation approach:</p>
          
          <div style="background: #f8f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #4c1d95; margin-top: 0;">Implementation Timeline</h3>
            
            <div style="margin-bottom: 15px;">
              <strong>Phase 1: Discovery & Planning (Weeks 1-2)</strong>
              <ul>
                <li>Process mapping and requirement analysis</li>
                <li>Technical feasibility assessment</li>
                <li>ROI projection and success metrics</li>
              </ul>
            </div>
            
            <div style="margin-bottom: 15px;">
              <strong>Phase 2: Pilot Implementation (Weeks 3-6)</strong>
              <ul>
                <li>Small-scale deployment with your team</li>
                <li>Testing and refinement</li>
                <li>User training and adoption support</li>
              </ul>
            </div>
            
            <div style="margin-bottom: 0;">
              <strong>Phase 3: Full Rollout (Weeks 7-12)</strong>
              <ul>
                <li>Company-wide deployment</li>
                <li>Performance monitoring and optimization</li>
                <li>Ongoing support and maintenance</li>
              </ul>
            </div>
          </div>
          
          <p><strong>Budget Alignment:</strong> Your indicated budget range (${lead.budgetRange}) aligns well with this approach. We can structure payments across phases to match your cash flow.</p>
          
          <p><strong>Timeline Match:</strong> Given your "${lead.desiredStart}" preference, we can adjust the schedule to meet your needs.</p>
          
          <div style="background: #ecfdf5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h4 style="color: #065f46; margin-top: 0;">Ready for a Quick Chat?</h4>
            <p style="margin-bottom: 15px;">I'd love to discuss your specific challenges and show you exactly how ${selectedUseCase} would work in your environment.</p>
            <a href="https://calendly.com/gerperdisatt/acuity-ai-strategy-session" style="background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">Book a 15-min Strategy Call</a>
          </div>
          
          <p>I'll also be sending you a relevant case study from a similar company that achieved great results with this approach.</p>
          
          <p>Best regards,<br>Acuity AI Team</p>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; font-size: 12px; color: #6b7280;">
            <p>P.S. No pressure - this roadmap is yours to keep and review at your own pace. We're here when you're ready to move forward.</p>
          </div>
        </div>
      `
    };
  }

  // Low-intent educational resources email
  static lowIntentEducationalResources(lead: any) {
    return {
      subject: "AI Automation Best Practices Guide + Weekly Insights",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #7c3aed;">Your AI Automation Resource Pack</h2>
          
          <p>Hi there,</p>
          
          <p>Thanks for exploring AI automation opportunities! I'm excited to share some valuable resources that will help you make smart automation decisions.</p>
          
          <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #0c4a6e; margin-top: 0;">📘 AI Automation Best Practices Guide</h3>
            <p>This comprehensive 20-page guide covers:</p>
            <ul>
              <li><strong>Opportunity Assessment:</strong> How to identify the best automation targets</li>
              <li><strong>Implementation Framework:</strong> Step-by-step deployment methodology</li>
              <li><strong>ROI Calculator:</strong> Templates to measure and predict returns</li>
              <li><strong>Common Pitfalls:</strong> What to avoid (learned from 100+ implementations)</li>
              <li><strong>Real Case Studies:</strong> Success stories from SMBs like yours</li>
            </ul>
            <a href="#" style="background: #0ea5e9; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">Download Your Guide</a>
          </div>
          
          <div style="background: #fefce8; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #92400e; margin-top: 0;">📧 Weekly AI Insights Newsletter</h3>
            <p>I've also added you to our "AI Insights" newsletter where you'll get:</p>
            <ul>
              <li>Practical automation tips (5-min read)</li>
              <li>New tool spotlights and reviews</li>
              <li>Success stories and lessons learned</li>
              <li>Industry trends and opportunities</li>
            </ul>
            <p style="font-size: 14px; color: #92400e;"><em>First issue arrives this Friday. Unsubscribe anytime with one click.</em></p>
          </div>
          
          <p><strong>What This Means for You:</strong> Most businesses using this guide identify 3-5 automation opportunities within their first week of reading. The average time savings? 15-20 hours per week.</p>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h4 style="color: #374151; margin-top: 0;">When You're Ready to Move Faster</h4>
            <p>No pressure at all - these resources are yours to explore at your own pace. But if your priorities change and you'd like hands-on help implementing any of these strategies, just reply to any of our emails.</p>
            <p>We'll prioritize your project and can typically start discovery calls within 48 hours.</p>
          </div>
          
          <p>Enjoy the guide, and I look forward to sharing more insights with you!</p>
          
          <p>Best regards,<br>Acuity AI Team</p>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; font-size: 12px; color: #6b7280;">
            <p>P.S. If you found the guide helpful, I'd love to hear about it. Your feedback helps us create even better resources for business owners like you.</p>
          </div>
        </div>
      `
    };
  }

  // Follow-up email for medium-intent leads (sent 3 days later)
  static mediumIntentFollowUp(lead: any, selectedUseCase: string) {
    return {
      subject: `Quick follow-up: ${selectedUseCase} implementation questions?`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #7c3aed;">Quick Check-in</h2>
          
          <p>Hi there,</p>
          
          <p>I sent over the ${selectedUseCase} implementation roadmap a few days ago and wanted to check if you had any questions.</p>
          
          <p>A few quick questions that might help:</p>
          <ul>
            <li>Does the timeline align with your ${lead.desiredStart} preference?</li>
            <li>Are there specific challenges in your current process we should prioritize?</li>
            <li>Would a brief demo of ${selectedUseCase} in action be helpful?</li>
          </ul>
          
          <div style="background: #ecfdf5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>No obligation - just want to make sure you have what you need to make an informed decision.</strong></p>
            <a href="https://calendly.com/gerperdisatt/acuity-ai-strategy-session" style="background: #059669; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">Quick 10-min Q&A Call</a>
          </div>
          
          <p>If now isn't the right time, no worries at all. I'll check back in a few weeks.</p>
          
          <p>Best,<br>Acuity AI Team</p>
        </div>
      `
    };
  }
}