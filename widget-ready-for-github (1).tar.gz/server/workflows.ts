import type { QualificationLead } from "@shared/schema";

// Webhook payload for Zapier integration
interface ZapierWebhook {
  lead_email: string;
  lead_tier: string;
  lead_score: number;
  selected_use_case: string;
  company_size: string;
  budget_range: string;
  desired_start: string;
  workflow_type: string;
  email_template: string;
  follow_up_days: number;
  created_at: string;
}

// Lead workflow manager with Zapier webhook integration
export class LeadWorkflowManager {
  
  // Generate follow-up actions based on lead tier
  static async triggerWorkflow(lead: QualificationLead, leadData: any) {
    console.log(`Triggering workflow for ${lead.leadTier} lead: ${lead.email}`);
    
    switch (lead.leadTier) {
      case "High-Intent":
        return await this.highIntentWorkflow(lead, leadData);
      case "Medium-Intent":
        return await this.mediumIntentWorkflow(lead, leadData);
      case "Low-Intent":
        return await this.lowIntentWorkflow(lead, leadData);
      default:
        console.log("Unknown lead tier, skipping workflow");
        return null;
    }
  }

  // High-intent: Direct to booking
  private static async highIntentWorkflow(lead: QualificationLead, leadData: any) {
    // Log for CRM/email platform integration
    console.log(`HIGH-INTENT LEAD: ${lead.email}
    - Score: ${lead.leadScore}
    - Budget: ${leadData.budgetRange}
    - Timeline: ${leadData.desiredStart}
    - Selected Solution: ${lead.selectedUseCaseTitle}
    
    ACTION: Directed to Calendly booking`);
    
    return {
      action: "calendly_redirect",
      priority: "urgent",
      followUpHours: 2
    };
  }

  // Medium-intent: Tailored implementation outline + team connection
  private static async mediumIntentWorkflow(lead: QualificationLead, leadData: any) {
    const webhookPayload: ZapierWebhook = {
      lead_email: lead.email,
      lead_tier: lead.leadTier,
      lead_score: lead.leadScore,
      selected_use_case: lead.selectedUseCaseTitle || "Not specified",
      company_size: leadData.companySize,
      budget_range: leadData.budgetRange,
      desired_start: leadData.desiredStart,
      workflow_type: "medium_intent_nurture",
      email_template: "implementation_outline",
      follow_up_days: 4,
      created_at: new Date().toISOString()
    };

    // Send to Zapier webhook for Dripify/email automation
    await this.sendToZapier(webhookPayload, "medium-intent");
    
    return {
      action: "implementation_outline",
      priority: "medium",
      followUpHours: 96,
      emailSequence: "medium_intent_nurture"
    };
  }

  // Low-intent: Resource sharing + educational nurture
  private static async lowIntentWorkflow(lead: QualificationLead, leadData: any) {
    const webhookPayload: ZapierWebhook = {
      lead_email: lead.email,
      lead_tier: lead.leadTier,
      lead_score: lead.leadScore,
      selected_use_case: lead.selectedUseCaseTitle || "Not specified",
      company_size: leadData.companySize,
      budget_range: leadData.budgetRange,
      desired_start: leadData.desiredStart,
      workflow_type: "low_intent_nurture",
      email_template: "educational_resources",
      follow_up_days: 14,
      created_at: new Date().toISOString()
    };

    // Send to Zapier webhook for Dripify/email automation
    await this.sendToZapier(webhookPayload, "low-intent");
    
    return {
      action: "educational_resources",
      priority: "low",
      followUpHours: 336,
      emailSequence: "educational_nurture"
    };
  }

  // Send webhook to Zapier for automation
  private static async sendToZapier(payload: ZapierWebhook, workflowType: string): Promise<boolean> {
    try {
      // Zapier webhook URL (you'll configure this in your Zapier account)
      const zapierWebhookUrl = process.env.ZAPIER_WEBHOOK_URL;
      
      if (!zapierWebhookUrl) {
        console.log(`
========== ZAPIER WEBHOOK READY ==========
Workflow Type: ${workflowType}
Lead: ${payload.lead_email}
Payload:`, JSON.stringify(payload, null, 2), `
==========================================
        `);
        return true;
      }

      const response = await fetch(zapierWebhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        console.log(`Zapier webhook sent successfully for ${payload.lead_email}`);
        return true;
      } else {
        console.error(`Zapier webhook failed: ${response.status}`);
        return false;
      }
    } catch (error) {
      console.error('Error sending Zapier webhook:', error);
      return false;
    }
  }

  // Email content for medium-intent leads (for Zapier template reference)
  private static async sendMediumIntentEmail(lead: QualificationLead, leadData: any) {
    const emailContent = {
      to: lead.email,
      subject: `Your Custom ${lead.selectedUseCaseTitle} Implementation Roadmap`,
      body: `Hi there,

Thank you for your interest in AI automation solutions, specifically ${lead.selectedUseCaseTitle}.

Based on your company size (${leadData.companySize}) and budget range (${leadData.budgetRange}), I've prepared a tailored implementation outline that maps out:

• Phase 1: Assessment and planning (Week 1-2)
• Phase 2: Pilot implementation (Week 3-6) 
• Phase 3: Full rollout and optimization (Week 7-12)

I'll be sending this detailed roadmap to your inbox within the next 4 hours, along with relevant case studies from similar companies in your sector.

Would you be available for a 15-minute strategy call this week to discuss your specific challenges and timeline?

Best regards,
Acuity AI Team

P.S. Based on your ${leadData.desiredStart} timeline, we can fast-track the initial assessment if needed.`
    };

    // Log email for manual sending or CRM integration
    console.log("MEDIUM-INTENT EMAIL READY:", emailContent);
    return emailContent;
  }

  // Email content for low-intent leads  
  private static async sendLowIntentEmail(lead: QualificationLead, leadData: any) {
    const emailContent = {
      to: lead.email,
      subject: "AI Automation Best Practices Guide (Free Resource)",
      body: `Hi there,

Thanks for exploring AI automation opportunities with us!

I'm sending you our comprehensive "AI Automation Best Practices Guide" - a 20-page resource that covers:

• How to identify the best automation opportunities in your business
• Step-by-step implementation frameworks
• Common pitfalls and how to avoid them  
• ROI calculation templates
• Real case studies from SMBs like yours

This guide typically helps businesses save 15-20 hours per week through smart automation choices.

I'll also be adding you to our weekly "AI Insights" newsletter where we share practical tips and success stories.

Feel free to reach out when you're ready to explore implementation - no pressure, just helpful resources in the meantime.

Best regards,
Acuity AI Team

P.S. If your priorities change and you'd like to move faster, just reply to any of our emails and we'll prioritize your project.`
    };

    console.log("LOW-INTENT EMAIL READY:", emailContent);
    return emailContent;
  }
}