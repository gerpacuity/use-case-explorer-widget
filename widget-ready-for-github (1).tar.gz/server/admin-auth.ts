// Simple admin authentication for lead data access
import type { Request, Response, NextFunction } from "express";

const ADMIN_TOKEN = process.env.ADMIN_API_TOKEN || "acuity_admin_2025";

export function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace('Bearer ', '');

  if (!token || token !== ADMIN_TOKEN) {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Valid admin token required"
    });
  }

  next();
}

export function requireAdminLogin(req: Request, res: Response, next: NextFunction) {
  // Simple session-based auth for web dashboard
  if (req.session?.isAdmin) {
    return next();
  }

  res.redirect('/admin/login');
}