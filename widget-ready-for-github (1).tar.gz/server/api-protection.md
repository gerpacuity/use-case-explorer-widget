# API Protection & Rate Limiting Strategy

## Overview
Comprehensive protection against misuse, abuse, and excessive API costs for the Acuity AI Use Case Explorer widget.

## Rate Limiting Layers

### 1. Use Case Generation Endpoint (`/api/live-use-cases`)
- **Request Limit**: 10 requests per IP per 15 minutes
- **Slowdown**: After 5 requests, add 2-second delay (max 10 seconds)
- **Cost Tracking**: $5 hourly limit per IP (estimated $0.015/request)
- **Key Strategy**: IP + User-Agent combination to prevent simple bypasses

### 2. Qualification Endpoint (`/api/qualify-lead`)  
- **Request Limit**: 3 submissions per IP per hour
- **Purpose**: Prevent lead generation spam and abuse
- **Key Strategy**: IP + User-Agent combination

### 3. Content Moderation & Spam Detection
- **Inappropriate Content**: Block explicit, illegal, or harmful terms
- **Spam Patterns**: Detect repetitive characters, keyboard mashing, excessive special characters
- **Quality Thresholds**: Minimum meaningful content requirements
- **Low-Quality Capping**: Suspicious submissions marked as low-intent leads

## Cost Protection Measures

### API Usage Tracking
- **In-Memory Tracking**: Per-IP cost and request counting with hourly resets
- **Cost Estimation**: $0.015 per OpenAI gpt-4o request (2000 max tokens)
- **Hard Limits**: 
  - $5 per hour per IP
  - 50 requests per hour per IP (regardless of cost)

### Emergency Scenarios
1. **Automated Scraping**: Rate limits + slowdown prevent rapid harvesting
2. **Competitor Intelligence**: Limited requests prevent systematic exploration
3. **API Cost Attacks**: Cost tracking prevents runaway expenses
4. **Lead Generation Spam**: Qualification rate limiting prevents abuse

## Bypass Prevention

### Key Generation Strategy
- Uses `IP + User-Agent` combination for tracking
- Prevents simple IP rotation attacks
- More sophisticated than IP-only tracking

### Development Environment
- Skips rate limiting for localhost/127.0.0.1
- Maintains development productivity

## Monitoring & Alerts

### Current Implementation
- Console logging for workflow triggers
- Database storage of all queries and leads
- Real-time spam detection and blocking

### Recommended Additions (Future)
- Redis for distributed rate limiting in production
- Email alerts for unusual usage patterns
- Dashboard for monitoring API costs and abuse attempts
- Geographic blocking for known bad actors

## Configuration Values

```javascript
// Use Case Endpoint
windowMs: 15 * 60 * 1000,  // 15 minutes
max: 10,                   // 10 requests per window
delayAfter: 5,             // Start slowdown after 5 requests
delayMs: 2000,             // 2 second delay increment
maxDelayMs: 10000,         // 10 second maximum delay

// Qualification Endpoint  
windowMs: 60 * 60 * 1000,  // 1 hour
max: 3,                    // 3 submissions per window

// Cost Limits
costLimit: 5.00,           // $5 per hour per IP
requestLimit: 50,          // 50 requests per hour per IP
estimatedCost: 0.015,      // $0.015 per OpenAI request
```

## Testing Scenarios

### Legitimate Usage
- Business user exploring 3-5 use cases: ✅ No restrictions
- Multiple team members from same office: ✅ Reasonable limits
- User iterating on requirements: ✅ Slowdown provides natural pacing

### Attack Scenarios
- Automated scraping bot: ❌ Blocked by rate limits + content moderation  
- Competitor doing reconnaissance: ❌ Limited to 10 queries per 15 minutes
- Cost attack via API abuse: ❌ Blocked at $5/hour threshold
- Lead spam/fake submissions: ❌ Blocked by qualification rate limits

## Future Enhancements

1. **Redis Integration**: For production-scale distributed rate limiting
2. **Geographic Analysis**: Block regions with high abuse rates
3. **Behavioral Analysis**: Track patterns to identify sophisticated attacks
4. **API Key Authentication**: For trusted partners to bypass limits
5. **Webhook Alerts**: Real-time notifications for abuse attempts