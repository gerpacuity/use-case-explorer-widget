import { z } from "zod";
import { pgTable, text, integer, timestamp, serial, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";

// Database Tables
export const useCaseQueries = pgTable("use_case_queries", {
  id: serial("id").primaryKey(),
  sector: varchar("sector", { length: 100 }),
  challenge: varchar("challenge", { length: 100 }),
  keywords: text("keywords"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const qualificationLeads = pgTable("qualification_leads", {
  id: serial("id").primaryKey(),
  queryId: integer("query_id").references(() => useCaseQueries.id),
  selectedUseCaseTitle: text("selected_use_case_title"),
  email: varchar("email", { length: 255 }).notNull(),
  companySize: varchar("company_size", { length: 20 }).notNull(),
  budgetRange: varchar("budget_range", { length: 20 }).notNull(),
  desiredStart: varchar("desired_start", { length: 20 }).notNull(),
  leadScore: integer("lead_score").notNull(),
  leadTier: varchar("lead_tier", { length: 20 }).notNull(), // High-Intent, Medium-Intent, Low-Intent
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const useCaseResults = pgTable("use_case_results", {
  id: serial("id").primaryKey(),
  queryId: integer("query_id").references(() => useCaseQueries.id),
  title: text("title").notNull(),
  valueProposition: text("value_proposition").notNull(),
  complexity: varchar("complexity", { length: 10 }).notNull(),
  timeToValue: varchar("time_to_value", { length: 50 }).notNull(),
  potentialInvestment: varchar("potential_investment", { length: 10 }).notNull(),
  implementationType: varchar("implementation_type", { length: 20 }).notNull(),
  whyThisFitsYou: text("why_this_fits_you").notNull(),
  cta: text("cta").notNull(),
  roiMetric: text("roi_metric"), // New field for calculated ROI
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const useCaseQueriesRelations = relations(useCaseQueries, ({ many }) => ({
  results: many(useCaseResults),
  leads: many(qualificationLeads),
}));

export const useCaseResultsRelations = relations(useCaseResults, ({ one }) => ({
  query: one(useCaseQueries, {
    fields: [useCaseResults.queryId],
    references: [useCaseQueries.id],
  }),
}));

export const qualificationLeadsRelations = relations(qualificationLeads, ({ one }) => ({
  query: one(useCaseQueries, {
    fields: [qualificationLeads.queryId],
    references: [useCaseQueries.id],
  }),
}));

// Zod Schemas for API
export const useCaseRequestSchema = z.object({
  sector: z.string().optional(),
  challenge: z.string().optional(),
  keywords: z.string().optional(),
});

export const qualificationFormSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  companySize: z.enum(["1-10", "11-50", "51-200", "200+"]),
  budgetRange: z.enum(["<£1K", "£1-5K", "£5-10K", "£10K+"]),
  desiredStart: z.enum(["Immediately", "1-3 months", "Undecided"]),
});

export const useCaseSchema = z.object({
  title: z.string(),
  valueProposition: z.string(),
  complexity: z.enum(["Low", "Medium", "High"]),
  timeToValue: z.string(),
  potentialInvestment: z.enum(["Low", "Medium", "High"]),
  implementationType: z.enum(["Off-the-shelf", "Custom Build"]),
  whyThisFitsYou: z.string(),
  cta: z.string(),
  roiMetric: z.string().optional(), // New field for calculated ROI
});

export const useCaseResponseSchema = z.object({
  useCases: z.array(useCaseSchema),
});

// Database Insert Schemas
export const insertUseCaseQuerySchema = createInsertSchema(useCaseQueries).omit({
  id: true,
  createdAt: true,
});

export const insertUseCaseResultSchema = createInsertSchema(useCaseResults).omit({
  id: true,
  createdAt: true,
});

export const insertQualificationLeadSchema = createInsertSchema(qualificationLeads).omit({
  id: true,
  createdAt: true,
});

// Types
export type UseCaseRequest = z.infer<typeof useCaseRequestSchema>;
export type UseCase = z.infer<typeof useCaseSchema>;
export type UseCaseResponse = z.infer<typeof useCaseResponseSchema>;
export type QualificationForm = z.infer<typeof qualificationFormSchema>;

export type UseCaseQuery = typeof useCaseQueries.$inferSelect;
export type UseCaseResult = typeof useCaseResults.$inferSelect;
export type QualificationLead = typeof qualificationLeads.$inferSelect;
export type InsertUseCaseQuery = z.infer<typeof insertUseCaseQuerySchema>;
export type InsertUseCaseResult = z.infer<typeof insertUseCaseResultSchema>;
export type InsertQualificationLead = z.infer<typeof insertQualificationLeadSchema>;
