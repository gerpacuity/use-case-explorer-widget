# Deployment Commands - Step by Step

## Step 1: Add Remote Repository in Replit Git Pane

In the Git pane you have open, you need to add your remote repository:

1. **Click "Add Remote"** or look for a settings/config button in the Git pane
2. **Remote Name**: `origin`
3. **Remote URL**: `https://github.com/gerpacuity/use-case-explorer-widget.git`
4. **Save the remote configuration**

## Step 2: Stage and Push Changes

Once the remote is configured:

1. **Stage all files**: Click "Stage All" or select all changed files
2. **Commit message**: `"Initial deployment: AI Use Case Explorer Widget"`
3. **Commit the changes**
4. **Push to GitHub**: Click "Push" button

## Step 3: Deploy on Render

After your code is on GitHub:

### Render Setup:
1. Go to https://render.com
2. **New Web Service**
3. **Connect GitHub**: `gerpacuity/use-case-explorer-widget`
4. **Service Name**: `use-case-explorer-widget`
5. **Build Command**: `npm install && npm run build`
6. **Start Command**: `npm start`
7. **Instance Type**: Free (for testing) or Starter ($7/month for production)

### Environment Variables:
```
NODE_ENV=production
OPENAI_API_KEY=your-openai-api-key-here
ADMIN_API_TOKEN=secure-admin-token-123
```

### Database:
1. **Add PostgreSQL Database** (free tier available)
2. After deployment, run in Render console: `npm run db:push`

## Step 4: Test Your Widget

Your widget will be live at: `https://use-case-explorer-widget.onrender.com`

### Test URLs:
- **Main widget**: `/`
- **Admin login**: `/admin/login` (use ADMIN_API_TOKEN)
- **Admin dashboard**: `/admin/dashboard`
- **API health**: `/api/health`

## Step 5: Embed on Your SMB Page

```html
<iframe 
  src="https://use-case-explorer-widget.onrender.com/"
  width="100%" 
  height="800px"
  frameborder="0"
  style="border-radius: 16px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);"
  title="AI Use Case Explorer">
</iframe>
```

## Your Widget Features:

✅ **AI-Powered Use Case Generation** - OpenAI GPT-4 integration
✅ **Lead Qualification System** - Automated scoring and routing
✅ **Premium Glassmorphic Design** - Dark navy-to-purple gradients
✅ **Admin Dashboard** - Lead management and analytics
✅ **API Protection** - Rate limiting and spam detection
✅ **Database Analytics** - PostgreSQL with comprehensive tracking
✅ **Mobile Responsive** - Works on all devices
✅ **Webhook Ready** - For CRM integration

## Troubleshooting:

**If Git push fails:**
- Check GitHub repository exists and is public
- Verify remote URL is correct
- Try refreshing the Git pane

**If Render deployment fails:**
- Check build logs for npm install errors
- Verify environment variables are set
- Ensure PostgreSQL database is connected

**If widget doesn't load:**
- Check Render service is running
- Verify OpenAI API key is working
- Check browser console for errors

Your widget is production-ready and will capture qualified leads immediately!