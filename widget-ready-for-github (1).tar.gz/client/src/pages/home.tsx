import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Wand2, Clock, DollarSign, Settings, Calendar, Lightbulb, TriangleAlert, Plug, Wrench, ChevronDown, ChevronUp, Users, PoundSterling, Calendar as CalendarIcon, Mail, Building, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useCaseRequestSchema, qualificationFormSchema, type UseCaseRequest, type UseCaseResponse, type UseCase, type QualificationForm } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const sectorOptions = [
  "Finance & Accounting",
  "Retail & E-commerce", 
  "Healthcare",
  "Manufacturing",
  "Legal Services",
  "Marketing & Advertising",
  "Real Estate",
  "Consulting",
  "Technology",
  "Other"
];

const challengeOptions = [
  "Manual Data Entry",
  "Customer Service",
  "Document Processing", 
  "Email Management",
  "Reporting & Analytics",
  "Lead Generation",
  "Scheduling & Appointments",
  "Content Creation",
  "Inventory Management",
  "Other"
];

const timeToValueOptions = [
  "1-2 weeks",
  "3-4 weeks", 
  "1-2 months",
  "3+ months"
];

function getComplexityColor(complexity: string) {
  switch(complexity.toLowerCase()) {
    case 'low': return 'bg-green-100 text-green-800 border-green-200';
    case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    case 'high': return 'bg-red-100 text-red-800 border-red-200';
    default: return 'bg-gray-100 text-gray-800 border-gray-200';
  }
}

function getInvestmentColor(investment: string) {
  switch(investment.toLowerCase()) {
    case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
    case 'medium': return 'bg-purple-100 text-purple-800 border-purple-200';
    case 'high': return 'bg-indigo-100 text-indigo-800 border-indigo-200';
    default: return 'bg-gray-100 text-gray-800 border-gray-200';
  }
}

function getImplementationTypeColor(type: string) {
  switch(type.toLowerCase()) {
    case 'off-the-shelf': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    case 'custom build': return 'bg-orange-100 text-orange-800 border-orange-200';
    default: return 'bg-gray-100 text-gray-800 border-gray-200';
  }
}

function getImplementationIcon(type: string) {
  return type.toLowerCase() === 'off-the-shelf' ? Plug : Wrench;
}

function UseCaseCard({ useCase, onInterest }: { useCase: UseCase; onInterest: (useCase: UseCase) => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      whileHover={{ y: -2, scale: 1.01 }}
    >
      <Card className="border border-white/20 bg-white/5 backdrop-blur-xl hover:bg-white/10 transition-all duration-300 rounded-2xl overflow-hidden">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <h4 className="font-bold text-white text-lg leading-tight flex-1 pr-4">
              {useCase.title}
            </h4>
            <div className="flex items-center text-xs text-white/60 bg-white/10 px-3 py-1 rounded-full">
              {useCase.implementationType === 'Off-the-shelf' ? (
                <>
                  <Plug className="w-3 h-3 mr-1" />
                  Ready
                </>
              ) : (
                <>
                  <Wrench className="w-3 h-3 mr-1" />
                  Custom
                </>
              )}
            </div>
          </div>
          
          <p className="text-white/70 text-sm mb-4 leading-relaxed">
            {useCase.valueProposition}
          </p>
          
          <div className="flex items-center justify-between text-xs text-white/60 mb-6">
            <span className="flex items-center">
              <Clock className="w-3 h-3 mr-1" />
              {useCase.timeToValue}
            </span>
            <span className="flex items-center">
              <Settings className="w-3 h-3 mr-1" />
              {useCase.complexity} complexity
            </span>
            <span className="flex items-center">
              <DollarSign className="w-3 h-3 mr-1" />
              {useCase.potentialInvestment}
            </span>
          </div>
          
          <Button 
            onClick={() => onInterest(useCase)}
            className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white font-semibold transition-all duration-300 rounded-xl py-3 text-sm border-0"
          >
            LEARN MORE
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Home() {
  const [results, setResults] = useState<UseCase[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAllResults, setShowAllResults] = useState(false);
  const [showQualificationForm, setShowQualificationForm] = useState(false);
  const [selectedUseCase, setSelectedUseCase] = useState<UseCase | null>(null);
  const [queryId, setQueryId] = useState<number | null>(null);
  const [isQualified, setIsQualified] = useState(false);
  const [showSuccessBanner, setShowSuccessBanner] = useState(false);

  const qualificationForm = useForm<QualificationForm>({
    resolver: zodResolver(qualificationFormSchema),
    defaultValues: {
      email: "",
      companySize: "1-10",
      budgetRange: "<£1K",
      desiredStart: "Undecided",
    },
  });

  const form = useForm<UseCaseRequest>({
    resolver: zodResolver(useCaseRequestSchema),
    defaultValues: {
      sector: "",
      challenge: "",
      keywords: "",
    },
  });

  const generateUseCases = useMutation({
    mutationFn: async (data: UseCaseRequest) => {
      const params = new URLSearchParams();
      if (data.sector) params.append('sector', data.sector);
      if (data.challenge) params.append('challenge', data.challenge);
      if (data.keywords) params.append('q', data.keywords);

      const response = await apiRequest('GET', `/api/live-use-cases?${params.toString()}`);
      return response.json() as Promise<UseCaseResponse>;
    },
    onSuccess: (data) => {
      setResults(data.useCases);
      setShowResults(true);
      setError(null);
      setQueryId(data.queryId || null); // Capture the query ID for linking
    },
    onError: (error: any) => {
      setError(error.message || "Failed to generate use cases. Please try again.");
      setShowResults(false);
      setResults([]);
    },
  });

  const [qualificationResult, setQualificationResult] = useState<any>(null);

  const submitQualification = useMutation({
    mutationFn: async (data: QualificationForm) => {
      const submissionData = {
        ...data,
        selectedUseCaseTitle: selectedUseCase?.title,
        queryId: queryId,
      };
      const response = await apiRequest('POST', '/api/qualify-lead', submissionData);
      return response.json();
    },
    onSuccess: (data) => {
      setIsQualified(true);
      setShowQualificationForm(false);
      setQualificationResult(data);
    },
    onError: (error: any) => {
      setError(error.message || "Failed to submit qualification. Please try again.");
    },
  });

  const onSubmit = (data: UseCaseRequest) => {
    setError(null);
    setShowAllResults(false);
    setIsQualified(false);
    setShowQualificationForm(false);
    setSelectedUseCase(null);
    generateUseCases.mutate(data);
  };

  const handleUseCaseInterest = (useCase: UseCase) => {
    setSelectedUseCase(useCase);
    setShowQualificationForm(true);
  };

  const onQualificationSubmit = (data: QualificationForm) => {
    submitQualification.mutate(data);
  };

  return (
    <div className="w-full max-w-lg mx-auto">
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-purple-900 text-white rounded-2xl shadow-2xl overflow-hidden">
        <div className="p-4 sm:p-6">
          {/* Compact Glassmorphic Form Container */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-6 shadow-2xl">
            <div className="mb-4 sm:mb-6">
            <h2 className="text-lg sm:text-xl font-bold text-white mb-2 text-center">
              AI Use Case Explorer
            </h2>
            <p className="text-white/70 text-center text-xs sm:text-sm">
              Discover tailored solutions for your business
            </p>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3 sm:space-y-4">
              {/* Single Column for Embedded Widget */}
              <div className="space-y-3 sm:space-y-4">
                {/* Industry */}
                <FormField
                  control={form.control}
                  name="sector"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs sm:text-sm font-semibold text-white mb-1 block">
                        Industry
                      </FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger className="h-10 sm:h-12 px-3 sm:px-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:border-white/40 focus:border-white/60 focus:ring-0 transition-all text-white font-medium shadow-lg text-sm">
                            <SelectValue placeholder="Select industry" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-slate-800/95 backdrop-blur-xl border-white/20">
                          {sectorOptions.map((option) => (
                            <SelectItem key={option} value={option} className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />

                {/* Challenge */}
                <FormField
                  control={form.control}
                  name="challenge"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs sm:text-sm font-semibold text-white mb-1 block">
                        Challenge
                      </FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger className="h-10 sm:h-12 px-3 sm:px-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:border-white/40 focus:border-white/60 focus:ring-0 transition-all text-white font-medium shadow-lg text-sm">
                            <SelectValue placeholder="Primary challenge" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-slate-800/95 backdrop-blur-xl border-white/20">
                          {challengeOptions.map((option) => (
                            <SelectItem key={option} value={option} className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
            </div>

              {/* Compact Context */}
              <FormField
                control={form.control}
                name="keywords"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs sm:text-sm font-semibold text-white mb-1 block">
                      Current Situation
                      <span className="text-white/50 text-xs font-normal ml-1">(Optional)</span>
                    </FormLabel>
                    
                    {/* Compact Examples */}
                    <div className="mb-3 p-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl">
                      <p className="font-medium text-white/90 mb-1 text-xs">Examples:</p>
                      <div className="space-y-1 text-xs text-white/60">
                        <p>"Process 200+ invoices weekly"</p>
                        <p>"2h daily sorting emails"</p>
                      </div>
                    </div>
                    
                    <FormControl>
                      <Textarea
                        {...field}
                        rows={3}
                        placeholder="Describe your processes and manual tasks..."
                        className="px-3 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:border-white/40 focus:border-white/60 focus:ring-0 transition-all resize-none text-white font-medium placeholder:text-white/50 shadow-lg text-sm"
                      />
                    </FormControl>
                    {field.value && field.value.length < 20 && (
                      <p className="text-amber-400 text-xs mt-1">
                        Add {20 - field.value.length} more characters for better recommendations
                      </p>
                    )}
                  </FormItem>
                )}
              />

              {/* Compact Premium CTA */}
              <div className="text-center pt-4 sm:pt-6">
                <Button
                  type="submit"
                  disabled={generateUseCases.isPending || !form.watch('keywords') || (form.watch('keywords')?.length || 0) < 20}
                  className="w-full px-6 py-3 sm:py-4 bg-gradient-to-r from-purple-500/80 to-blue-500/80 backdrop-blur-sm hover:from-purple-600/90 hover:to-blue-600/90 text-white font-bold rounded-2xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl border border-white/20 hover:shadow-purple-500/25 hover:scale-[1.02] transform text-sm sm:text-base"
                >
                  {generateUseCases.isPending ? "Analyzing..." : "EXPLORE USE CASES"}
                </Button>
                <p className="text-white/60 text-xs mt-2 font-medium">
                  Instant results • Vendor-neutral
                </p>
              </div>
            </form>
          </Form>
          </div>
        </div>

        {/* Glassmorphic Loading */}
        <AnimatePresence>
          {generateUseCases.isPending && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-6 shadow-2xl text-center"
            >
              <div className="inline-flex items-center">
                <div className="animate-spin rounded-full h-6 w-6 border-2 border-white/20 border-t-purple-400 mr-3"></div>
                <span className="text-white font-semibold text-sm sm:text-base">
                  Analyzing your business...
                </span>
              </div>
              <p className="text-white/60 mt-2 text-xs sm:text-sm">
                Finding opportunities
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Error State */}
        <AnimatePresence>
          {showSuccessBanner && (
            <motion.div
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              className="bg-emerald-500/10 backdrop-blur-xl border border-emerald-400/20 rounded-2xl p-6 text-center mb-6"
            >
              <div className="flex items-center justify-center mb-2">
                <div className="w-8 h-8 bg-emerald-400/20 backdrop-blur-sm border border-white/20 rounded-full flex items-center justify-center mr-3">
                  <Calendar className="w-4 h-4 text-emerald-300" />
                </div>
                <span className="text-emerald-200 font-bold text-lg">
                  Booking Confirmed!
                </span>
              </div>
              <p className="text-emerald-300/80 font-medium text-sm">
                Thanks for booking! We'll be in touch within 24 hours to confirm your strategy session.
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-red-500/10 backdrop-blur-sm border border-red-400/30 rounded-2xl p-6 text-center mb-6 shadow-xl"
            >
              <div className="flex items-center justify-center mb-3">
                <TriangleAlert className="w-6 h-6 text-red-400 mr-3" />
                <span className="text-red-200 font-bold text-lg">
                  {error.includes("moderation") ? "Content Alert" : "Error"}
                </span>
              </div>
              <p className="text-red-300 font-medium">{error}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Results Section */}
        <AnimatePresence>
          {showResults && results.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="text-center mb-4 sm:mb-6">
                <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
                  Your Opportunities
                </h3>
                <p className="text-white/70 text-sm">
                  Tailored solutions for your business
                </p>
              </div>
              


              {/* Qualified Success Message */}
              {isQualified && qualificationResult && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 mb-6"
                >
                  <div className="text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-emerald-400/20 to-green-400/20 backdrop-blur-sm border border-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Wand2 className="w-6 h-6 text-emerald-300" />
                    </div>
                    <h4 className="text-xl font-bold text-white mb-3">
                      {qualificationResult.leadTier === "High-Intent" ? "Perfect! You're Ready for a Strategy Session" : 
                       qualificationResult.leadTier === "Medium-Intent" ? "Great! Let's Plan Your Next Steps" :
                       "Thanks! We'll Send You Helpful Resources"}
                    </h4>
                    <p className="text-white/70 mb-6 text-sm">
                      {qualificationResult.message}
                    </p>
                    {qualificationResult.leadTier === "High-Intent" && (
                      <div className="space-y-4">
                        <p className="text-white/80 font-medium text-sm">
                          Let's discuss your specific requirements and create an implementation plan.
                        </p>
                        <Button 
                          onClick={() => {
                            window.open(qualificationResult.nextSteps, '_blank');
                            setShowSuccessBanner(true);
                            setTimeout(() => setShowSuccessBanner(false), 8000);
                          }}
                          className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white font-semibold rounded-xl transition-all border-0"
                        >
                          <Calendar className="w-4 h-4 mr-2" />
                          Book Your Strategy Session
                        </Button>
                      </div>
                    )}
                    {qualificationResult.leadTier === "Medium-Intent" && (
                      <p className="text-white/80 font-medium text-sm">
                        {qualificationResult.nextSteps}
                      </p>
                    )}
                    {qualificationResult.leadTier === "Low-Intent" && (
                      <p className="text-white/80 font-medium text-sm">
                        {qualificationResult.nextSteps}
                      </p>
                    )}
                  </div>
                </motion.div>
              )}
              
              {/* Use Cases - Single Column for Embedded Widget */}
              <div className="space-y-3 sm:space-y-4">
                <AnimatePresence>
                  {(showAllResults ? results : results.slice(0, 3)).map((useCase, index) => (
                    <motion.div
                      key={index}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      className="w-full"
                    >
                      <UseCaseCard useCase={useCase} onInterest={handleUseCaseInterest} />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
              
              {/* Show More Button - Fixed Animation */}
              {results.length > 3 && (
                <motion.div 
                  className="text-center mt-6"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAllResults(!showAllResults)}
                    className="px-6 py-2 bg-white/10 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20 transition-all duration-200 rounded-xl"
                  >
                    <div className="flex items-center">
                      {showAllResults ? (
                        <>
                          <ChevronUp className="w-4 h-4 mr-2" />
                          Show Less
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-4 h-4 mr-2" />
                          Show More Options
                        </>
                      )}
                    </div>
                  </Button>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Qualification Modal */}
        <Dialog open={showQualificationForm && !!selectedUseCase && !isQualified} onOpenChange={(open) => {
          if (!open) {
            setShowQualificationForm(false);
            setSelectedUseCase(null);
          }
        }}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900/95 backdrop-blur-xl border-white/20">
            <DialogHeader>
              <DialogTitle className="text-3xl font-bold text-white mb-4 text-center">
                Let's Make This Happen
              </DialogTitle>
              {selectedUseCase && (
                <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-2xl p-6 mb-6">
                  <h4 className="text-xl font-bold text-white mb-3">
                    {selectedUseCase.title}
                  </h4>
                  <p className="text-white/80 leading-relaxed">
                    {selectedUseCase.valueProposition}
                  </p>
                </div>
              )}
              <DialogDescription className="text-white/70 text-center">
                Quick details so we can provide personalized guidance and next steps.
              </DialogDescription>
            </DialogHeader>

            <Form {...qualificationForm}>
              <form onSubmit={qualificationForm.handleSubmit(onQualificationSubmit)} className="space-y-6 mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Email */}
                  <FormField
                    control={qualificationForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold text-white mb-2 block">
                          Email Address
                        </FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            type="email"
                            placeholder="your@company.com"
                            className="h-12 px-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:border-white/40 focus:border-white/60 focus:ring-0 transition-all text-white font-medium shadow-lg"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {/* Company Size */}
                  <FormField
                    control={qualificationForm.control}
                    name="companySize"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold text-white mb-2 block">
                          Company Size
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="h-12 px-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:border-white/40 focus:border-white/60 focus:ring-0 transition-all text-white font-medium shadow-lg">
                              <SelectValue placeholder="Select company size" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-slate-800/95 backdrop-blur-xl border-white/20">
                            <SelectItem value="1-10" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">1-10 employees</SelectItem>
                            <SelectItem value="11-50" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">11-50 employees</SelectItem>
                            <SelectItem value="51-200" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">51-200 employees</SelectItem>
                            <SelectItem value="200+" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">200+ employees</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />

                  {/* Budget Range */}
                  <FormField
                    control={qualificationForm.control}
                    name="budgetRange"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold text-white mb-2 block">
                          Budget Range
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="h-12 px-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:border-white/40 focus:border-white/60 focus:ring-0 transition-all text-white font-medium shadow-lg">
                              <SelectValue placeholder="Select budget range" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-slate-800/95 backdrop-blur-xl border-white/20">
                            <SelectItem value="<£1K" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">Less than £1,000</SelectItem>
                            <SelectItem value="£1-5K" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">£1,000 - £5,000</SelectItem>
                            <SelectItem value="£5-10K" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">£5,000 - £10,000</SelectItem>
                            <SelectItem value="£10K+" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">£10,000+</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />

                  {/* Desired Start */}
                  <FormField
                    control={qualificationForm.control}
                    name="desiredStart"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold text-white mb-2 block">
                          Timeline
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="h-12 px-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:border-white/40 focus:border-white/60 focus:ring-0 transition-all text-white font-medium shadow-lg">
                              <SelectValue placeholder="Select timeline" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-slate-800/95 backdrop-blur-xl border-white/20">
                            <SelectItem value="Immediately" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">Immediately</SelectItem>
                            <SelectItem value="1-3 months" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">1-3 months</SelectItem>
                            <SelectItem value="Undecided" className="text-white hover:bg-purple-500/20 focus:bg-purple-500/30 focus:text-white">Undecided</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="pt-6 border-t border-white/20">
                  <Button
                    type="submit"
                    disabled={submitQualification.isPending}
                    className="w-full px-8 py-4 bg-gradient-to-r from-purple-500/80 to-blue-500/80 backdrop-blur-sm hover:from-purple-600/90 hover:to-blue-600/90 text-white font-bold rounded-2xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl border border-white/20 hover:shadow-purple-500/25 hover:scale-105 transform"
                  >
                    {submitQualification.isPending ? "Processing..." : "GET IMPLEMENTATION PLAN"}
                  </Button>
                  <p className="text-white/60 text-xs text-center mt-4 font-medium">
                    Personalized guidance • No sales pitch • Fast ROI focus
                  </p>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Success Modal */}
        <Dialog open={isQualified && !!qualificationResult} onOpenChange={(open) => {
          if (!open) {
            setIsQualified(false);
            setQualificationResult(null);
            setSelectedUseCase(null);
          }
        }}>
          <DialogContent className="max-w-lg bg-gradient-to-br from-slate-900/95 to-purple-900/95 backdrop-blur-xl border border-white/20 text-white">
            <DialogHeader>
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-emerald-400/20 to-green-400/20 backdrop-blur-sm border border-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Wand2 className="w-8 h-8 text-emerald-300" />
                </div>
                <DialogTitle className="text-2xl font-bold text-white mb-2">
                  {qualificationResult?.leadTier === "High-Intent" ? "Perfect! You're Ready for a Strategy Session" : 
                   qualificationResult?.leadTier === "Medium-Intent" ? "Great! Let's Plan Your Next Steps" :
                   "Thanks! We'll Send You Helpful Resources"}
                </DialogTitle>
              </div>
              <DialogDescription className="sr-only">
                Success message for qualification form completion
              </DialogDescription>
            </DialogHeader>
            <div className="text-center">
              <p className="text-white/70 mb-6 text-sm">
                {qualificationResult?.message}
              </p>
              {qualificationResult?.leadTier === "High-Intent" && (
                <div className="space-y-4">
                  <Button 
                    onClick={() => window.open(qualificationResult.nextSteps, '_blank')}
                    className="px-8 py-3 bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white font-semibold rounded-xl transition-all border-0"
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    Book Your Strategy Session
                  </Button>
                </div>
              )}
              {qualificationResult?.leadTier === "Medium-Intent" && (
                <p className="text-white/80 font-medium text-sm">
                  {qualificationResult.nextSteps}
                </p>
              )}
              {qualificationResult?.leadTier === "Low-Intent" && (
                <p className="text-white/80 font-medium text-sm">
                  {qualificationResult.nextSteps}
                </p>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
