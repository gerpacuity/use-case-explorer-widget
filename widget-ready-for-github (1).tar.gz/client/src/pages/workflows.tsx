import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Mail, 
  Calendar, 
  Clock, 
  User, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  Send,
  Eye
} from "lucide-react";
import { motion } from "framer-motion";

interface WorkflowAction {
  id: number;
  leadId: number;
  email: string;
  leadTier: string;
  actionType: string;
  scheduledFor: string;
  completed: boolean;
  selectedUseCase: string;
  companySize: string;
  budgetRange: string;
  createdAt: string;
}

export default function WorkflowsPage() {
  const [filter, setFilter] = useState<"all" | "pending" | "completed">("all");

  // Mock data - replace with actual API call
  const mockWorkflows: WorkflowAction[] = [
    {
      id: 1,
      leadId: 10,
      email: "sarah@techstartup.com",
      leadTier: "Medium-Intent",
      actionType: "implementation_outline",
      scheduledFor: "2025-01-29T18:00:00Z",
      completed: false,
      selectedUseCase: "AI-Powered Customer Support Automation",
      companySize: "11-50",
      budgetRange: "£5-10K",
      createdAt: "2025-01-29T14:25:00Z"
    },
    {
      id: 2,
      leadId: 9,
      email: "mike@retailstore.com", 
      leadTier: "Low-Intent",
      actionType: "educational_resources",
      scheduledFor: "2025-01-29T16:30:00Z",
      completed: true,
      selectedUseCase: "Inventory Management Automation",
      companySize: "1-10",
      budgetRange: "<£1K",
      createdAt: "2025-01-29T14:30:00Z"
    },
    {
      id: 3,
      leadId: 8,
      email: "david@consulting.co.uk",
      leadTier: "Medium-Intent", 
      actionType: "follow_up_call",
      scheduledFor: "2025-02-01T10:00:00Z",
      completed: false,
      selectedUseCase: "Document Processing Automation",
      companySize: "51-200",
      budgetRange: "£1-5K",
      createdAt: "2025-01-29T13:45:00Z"
    }
  ];

  const filteredWorkflows = mockWorkflows.filter(workflow => {
    if (filter === "pending") return !workflow.completed;
    if (filter === "completed") return workflow.completed;
    return true;
  });

  const stats = {
    totalWorkflows: mockWorkflows.length,
    pendingActions: mockWorkflows.filter(w => !w.completed).length,
    completedToday: mockWorkflows.filter(w => w.completed).length,
    mediumIntentActive: mockWorkflows.filter(w => w.leadTier === "Medium-Intent" && !w.completed).length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      <div className="max-w-7xl mx-auto p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-700 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-2">
            Lead Workflow Management
          </h1>
          <p className="text-slate-600">Automated follow-up sequences for medium and low-intent leads</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-blue-500" />
                <div>
                  <p className="text-2xl font-bold">{stats.totalWorkflows}</p>
                  <p className="text-sm text-slate-600">Total Workflows</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5 text-orange-500" />
                <div>
                  <p className="text-2xl font-bold">{stats.pendingActions}</p>
                  <p className="text-sm text-slate-600">Pending Actions</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <div>
                  <p className="text-2xl font-bold">{stats.completedToday}</p>
                  <p className="text-sm text-slate-600">Completed Today</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <User className="w-5 h-5 text-purple-500" />
                <div>
                  <p className="text-2xl font-bold">{stats.mediumIntentActive}</p>
                  <p className="text-sm text-slate-600">Medium-Intent Active</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filter Tabs */}
        <div className="flex space-x-4 mb-6">
          <Button
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => setFilter("all")}
          >
            All Workflows
          </Button>
          <Button
            variant={filter === "pending" ? "default" : "outline"}
            onClick={() => setFilter("pending")}
          >
            Pending ({stats.pendingActions})
          </Button>
          <Button
            variant={filter === "completed" ? "default" : "outline"}
            onClick={() => setFilter("completed")}
          >
            Completed ({stats.completedToday})
          </Button>
        </div>

        {/* Workflow List */}
        <div className="space-y-4">
          {filteredWorkflows.map((workflow, index) => (
            <motion.div
              key={workflow.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      {/* Lead Info Header */}
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="flex items-center space-x-2">
                          <Mail className="w-4 h-4 text-slate-500" />
                          <span className="font-medium">{workflow.email}</span>
                        </div>
                        <Badge 
                          variant={workflow.leadTier === "Medium-Intent" ? "default" : "secondary"}
                          className={workflow.leadTier === "Medium-Intent" ? "bg-orange-100 text-orange-800" : "bg-blue-100 text-blue-800"}
                        >
                          {workflow.leadTier}
                        </Badge>
                        <Badge 
                          variant={workflow.completed ? "default" : "outline"}
                          className={workflow.completed ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                        >
                          {workflow.completed ? "Completed" : "Pending"}
                        </Badge>
                      </div>

                      {/* Selected Use Case */}
                      <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 mb-4">
                        <p className="text-sm font-medium text-purple-800">Selected Solution:</p>
                        <p className="text-purple-700">{workflow.selectedUseCase}</p>
                      </div>

                      {/* Lead Details */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-4">
                        <div>
                          <span className="text-slate-600">Company Size:</span>
                          <span className="ml-2 font-medium">{workflow.companySize}</span>
                        </div>
                        <div>
                          <span className="text-slate-600">Budget:</span>
                          <span className="ml-2 font-medium">{workflow.budgetRange}</span>
                        </div>
                        <div>
                          <span className="text-slate-600">Scheduled:</span>
                          <span className="ml-2 font-medium">
                            {new Date(workflow.scheduledFor).toLocaleDateString()} at{" "}
                            {new Date(workflow.scheduledFor).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                          </span>
                        </div>
                      </div>

                      {/* Action Details */}
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                        <div className="flex items-center space-x-2 mb-2">
                          {workflow.actionType === "implementation_outline" && <Send className="w-4 h-4 text-blue-600" />}
                          {workflow.actionType === "educational_resources" && <Eye className="w-4 h-4 text-blue-600" />}
                          {workflow.actionType === "follow_up_call" && <Calendar className="w-4 h-4 text-blue-600" />}
                          <span className="font-medium text-blue-800">
                            {workflow.actionType === "implementation_outline" && "Send Implementation Outline"}
                            {workflow.actionType === "educational_resources" && "Send Educational Resources"}
                            {workflow.actionType === "follow_up_call" && "Schedule Follow-up Call"}
                          </span>
                        </div>
                        <p className="text-sm text-blue-700">
                          {workflow.actionType === "implementation_outline" && 
                            "Tailored roadmap, case studies, and timeline alignment based on their specific requirements."
                          }
                          {workflow.actionType === "educational_resources" && 
                            "Best practices guide, ROI calculator, and educational newsletter subscription."
                          }
                          {workflow.actionType === "follow_up_call" && 
                            "Personalized follow-up to address questions and gauge implementation readiness."
                          }
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="ml-6 flex flex-col space-y-2">
                      {!workflow.completed && (
                        <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                          Execute Now
                        </Button>
                      )}
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {filteredWorkflows.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-700 mb-2">No workflows found</h3>
              <p className="text-slate-500">
                {filter === "pending" ? "All workflows are completed!" : 
                 filter === "completed" ? "No completed workflows yet." :
                 "No workflows have been created yet."}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}