import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Target, 
  TrendingUp, 
  Calendar,
  Mail,
  Building,
  DollarSign,
  Clock,
  RefreshCw
} from "lucide-react";

interface Lead {
  id: number;
  email: string;
  companySize: string;
  budgetRange: string;
  desiredStart: string;
  leadScore: number;
  leadTier: string;
  selectedUseCaseTitle: string | null;
  sector: string | null;
  challenge: string | null;
  keywords: string | null;
  ipAddress: string | null;
  userAgent: string | null;
  createdAt: string;
}

interface DashboardData {
  stats: {
    totalLeads: number;
    recentLeads: number;
    highIntentLeads: number;
    totalQueries: number;
  };
  recentActivity: Lead[];
}

function getTierColor(tier: string) {
  switch(tier) {
    case 'High-Intent': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    case 'Medium-Intent': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    case 'Low-Intent': return 'bg-slate-100 text-slate-700 border-slate-300';
    default: return 'bg-gray-100 text-gray-800 border-gray-200';
  }
}

export default function AdminDashboard() {
  const [selectedPage, setSelectedPage] = useState<'dashboard' | 'leads'>('dashboard');

  const { data: dashboardData, isLoading: dashboardLoading, refetch: refetchDashboard } = useQuery<DashboardData>({
    queryKey: ['/api/admin/dashboard'],
    enabled: selectedPage === 'dashboard'
  });

  const { data: leadsData, isLoading: leadsLoading, refetch: refetchLeads } = useQuery<{leads: Lead[], pagination: any}>({
    queryKey: ['/api/admin/leads'],
    enabled: selectedPage === 'leads'
  });

  const handleRefresh = () => {
    if (selectedPage === 'dashboard') {
      refetchDashboard();
    } else {
      refetchLeads();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Admin Dashboard</h1>
            <p className="text-slate-600 mt-1">Monitor leads and use case submissions</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant={selectedPage === 'dashboard' ? 'default' : 'outline'}
              onClick={() => setSelectedPage('dashboard')}
            >
              Dashboard
            </Button>
            <Button
              variant={selectedPage === 'leads' ? 'default' : 'outline'}
              onClick={() => setSelectedPage('leads')}
            >
              All Leads
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={dashboardLoading || leadsLoading}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${(dashboardLoading || leadsLoading) ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {/* Dashboard View */}
        {selectedPage === 'dashboard' && (
          <div className="space-y-6">
            {/* Stats Cards */}
            {dashboardData && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-slate-600">Total Leads</p>
                          <p className="text-2xl font-bold text-slate-900">{dashboardData.stats.totalLeads}</p>
                        </div>
                        <Users className="w-8 h-8 text-blue-600" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-slate-600">This Week</p>
                          <p className="text-2xl font-bold text-slate-900">{dashboardData.stats.recentLeads}</p>
                        </div>
                        <TrendingUp className="w-8 h-8 text-green-600" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-slate-600">High-Intent</p>
                          <p className="text-2xl font-bold text-slate-900">{dashboardData.stats.highIntentLeads}</p>
                        </div>
                        <Target className="w-8 h-8 text-emerald-600" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-slate-600">Total Queries</p>
                          <p className="text-2xl font-bold text-slate-900">{dashboardData.stats.totalQueries}</p>
                        </div>
                        <TrendingUp className="w-8 h-8 text-purple-600" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            )}

            {/* Recent Activity */}
            {dashboardData && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="w-5 h-5 mr-2" />
                    Recent Lead Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardData.recentActivity.map((lead, index) => (
                      <motion.div
                        key={lead.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center justify-between p-4 bg-slate-50 rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                            <Mail className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <p className="font-medium text-slate-900">{lead.email}</p>
                            <div className="flex items-center space-x-2 text-sm text-slate-600 mt-1">
                              <Building className="w-3 h-3" />
                              <span>{lead.companySize}</span>
                              <DollarSign className="w-3 h-3 ml-2" />
                              <span>{lead.budgetRange}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="text-right">
                            <Badge variant="outline" className={getTierColor(lead.leadTier)}>
                              {lead.leadTier}
                            </Badge>
                            <p className="text-xs text-slate-500 mt-1">Score: {lead.leadScore}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-slate-500">
                              {new Date(lead.createdAt).toLocaleDateString()}
                            </p>
                            <p className="text-xs text-slate-500">
                              {new Date(lead.createdAt).toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* All Leads View */}
        {selectedPage === 'leads' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                All Lead Submissions
              </CardTitle>
            </CardHeader>
            <CardContent>
              {leadsData && (
                <div className="space-y-4">
                  {leadsData.leads.map((lead, index) => (
                    <motion.div
                      key={lead.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="border border-slate-200 rounded-lg p-6 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <Mail className="w-5 h-5 text-slate-600" />
                          <span className="font-medium text-slate-900">{lead.email}</span>
                          <Badge variant="outline" className={getTierColor(lead.leadTier)}>
                            {lead.leadTier}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-slate-600">
                            {new Date(lead.createdAt).toLocaleDateString()} at {new Date(lead.createdAt).toLocaleTimeString()}
                          </p>
                          <p className="text-xs text-slate-500">Lead Score: {lead.leadScore}</p>
                        </div>
                      </div>
                      <div className="space-y-4">
                        {/* Business Context */}
                        {(lead.sector || lead.challenge || lead.keywords) && (
                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <h5 className="font-semibold text-blue-800 mb-2">Business Context</h5>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                              {lead.sector && (
                                <div>
                                  <span className="text-blue-600 font-medium">Sector:</span>
                                  <p className="text-blue-800">{lead.sector}</p>
                                </div>
                              )}
                              {lead.challenge && (
                                <div>
                                  <span className="text-blue-600 font-medium">Challenge:</span>
                                  <p className="text-blue-800">{lead.challenge}</p>
                                </div>
                              )}
                              {lead.keywords && (
                                <div>
                                  <span className="text-blue-600 font-medium">Description:</span>
                                  <p className="text-blue-800">{lead.keywords}</p>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {/* Selected Use Case */}
                        {lead.selectedUseCaseTitle && (
                          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                            <h5 className="font-semibold text-purple-800 mb-2">Interested Solution</h5>
                            <p className="text-purple-800 font-medium">{lead.selectedUseCaseTitle}</p>
                          </div>
                        )}
                        
                        {/* Qualification Details */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div className="flex items-center space-x-2">
                            <Building className="w-4 h-4 text-slate-500" />
                            <span className="text-slate-600">Company Size:</span>
                            <span className="font-medium">{lead.companySize}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <DollarSign className="w-4 h-4 text-slate-500" />
                            <span className="text-slate-600">Budget:</span>
                            <span className="font-medium">{lead.budgetRange}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Calendar className="w-4 h-4 text-slate-500" />
                            <span className="text-slate-600">Timeline:</span>
                            <span className="font-medium">{lead.desiredStart}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Loading States */}
        {(dashboardLoading || leadsLoading) && (
          <div className="flex items-center justify-center py-12">
            <RefreshCw className="w-8 h-8 animate-spin text-slate-600" />
          </div>
        )}
      </div>
    </div>
  );
}