# Acuity AI Use Case Explorer Widget

A React-based microservice designed to be embedded as an iframe on SMB Services pages. The application helps visitors discover relevant AI automation use cases by filtering based on their sector, business challenges, and specific requirements using OpenAI's GPT-4.

## Features

- **AI-Powered Recommendations**: GPT-4 generates personalized use cases based on industry, challenges, and keywords
- **Lead Qualification Funnel**: Automated scoring system with High/Medium/Low intent tiers
- **Premium Design**: Glassmorphic UI with dark navy-to-purple gradients matching Acuity AI brand
- **Comprehensive Protection**: Multi-layer rate limiting, spam detection, and cost controls
- **Admin Dashboard**: Lead management, analytics, and data export capabilities
- **API Access**: RESTful endpoints for CRM integration and data extraction

## Quick Start

### Environment Variables
```bash
DATABASE_URL=postgresql://...
OPENAI_API_KEY=sk-...
ADMIN_API_TOKEN=your-secure-token
```

### Installation
```bash
npm install
npm run db:push  # Initialize database
npm run dev      # Start development server
```

### Production Build
```bash
npm run build
npm start
```

## Deployment on Render

1. Connect this GitHub repository to Render
2. Configure environment variables in Render dashboard
3. Deploy as a Web Service
4. Use the provided URL for iframe embedding

## Embedding

### Basic iframe Embed
```html
<iframe 
  src="https://your-widget.onrender.com/"
  width="100%" 
  height="800px"
  frameborder="0"
  style="border-radius: 16px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);"
  title="AI Use Case Explorer">
</iframe>
```

### Responsive Integration
```html
<div class="widget-container" style="max-width: 600px; margin: 0 auto;">
  <iframe src="https://your-widget.onrender.com/" width="100%" height="800px" frameborder="0"></iframe>
</div>
```

## Lead Data Access

### REST API
```bash
GET /admin/api/leads?tier=High-Intent&format=csv
Authorization: Bearer YOUR_ADMIN_TOKEN
```

### Admin Dashboard
Access at: `https://your-widget.onrender.com/admin/login`

## Tech Stack

- **Frontend**: React 18 + TypeScript + Tailwind CSS + shadcn/ui
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **AI**: OpenAI GPT-4
- **Authentication**: Session-based admin auth
- **Rate Limiting**: express-rate-limit + express-slow-down

## Security Features

- Rate limiting: 10 requests per 15 minutes for use cases
- Cost protection: $5 hourly limit per IP
- Spam detection and content moderation
- IP + User-Agent tracking to prevent bypasses
- Secure admin authentication for data access

## Performance

- Load time: <2 seconds
- Target conversion rate: >20%
- Average lead quality score: >60
- Zero spam in high-intent tier

## License

Proprietary - Acuity AI